class AmbientResonance {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private osc1: OscillatorNode | null = null;
  private osc2: OscillatorNode | null = null;
  private osc3: OscillatorNode | null = null;
  private initialized = false;
  private isMuted = true;

  constructor() {}

  init() {
    if (this.isMuted) return;
    if (this.initialized) return;

    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;

      this.ctx = new AudioContextClass();
      this.masterGain = this.ctx.createGain();
      
      // Extremely subtle gain level (0.02) to create a gentle background aura, not a loud beep
      this.masterGain.gain.setValueAtTime(0.02, this.ctx.currentTime);

      // Lowpass filter at 140 Hz to keep the sound exceptionally warm, smooth, and velvet-like
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(140, this.ctx.currentTime);
      filter.Q.setValueAtTime(1.2, this.ctx.currentTime);

      // Main grounding frequency: A2 (110 Hz) representing raw solid monolith mass
      this.osc1 = this.ctx.createOscillator();
      this.osc1.type = 'sine';
      this.osc1.frequency.setValueAtTime(110, this.ctx.currentTime);

      // Minor detune: 110.4 Hz to create a slowly moving, spacious binaural acoustic pulse
      this.osc2 = this.ctx.createOscillator();
      this.osc2.type = 'sine';
      this.osc2.frequency.setValueAtTime(110.4, this.ctx.currentTime);

      // Soft third harmonic at 220 Hz using a triangle wave (for a subtle, rich timber)
      this.osc3 = this.ctx.createOscillator();
      this.osc3.type = 'triangle';
      this.osc3.frequency.setValueAtTime(220, this.ctx.currentTime);
      
      const osc3Gain = this.ctx.createGain();
      osc3Gain.gain.setValueAtTime(0.12, this.ctx.currentTime); // 12% relative intensity

      // Connect nodes
      this.osc1.connect(filter);
      this.osc2.connect(filter);
      
      this.osc3.connect(osc3Gain);
      osc3Gain.connect(filter);

      filter.connect(this.masterGain);
      this.masterGain.connect(this.ctx.destination);

      // Start oscillators smoothly
      this.osc1.start(0);
      this.osc2.start(0);
      this.osc3.start(0);

      this.initialized = true;
    } catch (e) {
      console.warn('Web Audio API not fully supported or blocked:', e);
    }
  }

  setMute(mute: boolean) {
    this.isMuted = mute;
    if (mute) {
      if (this.ctx && this.ctx.state === 'running') {
        this.ctx.suspend();
      }
    } else {
      this.init();
      if (this.ctx) {
        if (this.ctx.state === 'suspended') {
          this.ctx.resume();
        }
      }
    }
  }

  playSuccessPing() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    // Force resume the audio context if it was suspended due to browser autoplace policies
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    try {
      const now = this.ctx.currentTime;
      
      // We synthesize a pristine, crystal-clear chime using elegant sine and triangle harmonics
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gainNode = this.ctx.createGain();

      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(880, now); // A5 chime note

      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(1318.51, now); // E6 high tone fifth harmonic

      // Create a gorgeous exponential decay envelope for a bell sound
      gainNode.gain.setValueAtTime(0, now);
      gainNode.gain.linearRampToValueAtTime(0.08, now + 0.01);
      gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 1.5);

      osc1.connect(gainNode);
      osc2.connect(gainNode);
      gainNode.connect(this.ctx.destination);

      osc1.start(now);
      osc2.start(now);

      osc1.stop(now + 1.5);
      osc2.stop(now + 1.5);
    } catch (e) {
      console.warn('Could not play success ping:', e);
    }
  }

  // Helper method to ensure context runs on initial user clicks/taps
  resumeOnInteraction() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }
}

export const ambientResonance = new AmbientResonance();
