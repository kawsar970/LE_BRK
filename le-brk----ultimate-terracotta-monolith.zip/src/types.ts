export type BrickFinish = 'classic' | 'obsidian' | 'sovereign' | 'moss';

export interface CustomizationState {
  finish: BrickFinish;
  engraving: string;
  velvetStand: boolean;
  organicMossStarter: boolean;
  perfumed: 'none' | 'eau_de_terre' | 'esprit_de_kiln';
  packaging: 'standard' | 'mahogany_chest' | 'carbon_vault';
}

export interface NewsArticle {
  headline: string;
  subheading: string;
  date: string;
  location: string;
  content: string[];
  editorialQuote: string;
  insiderScore: string;
}

export interface LeaderboardEntry {
  name: string;
  score: number;
  archetype: string;
  title: string;
}
