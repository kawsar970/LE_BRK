import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  ShieldCheck, 
  Layers, 
  ZapOff, 
  VolumeX, 
  Volume2,
  Compass, 
  ArrowRight, 
  ChevronDown, 
  Clock, 
  Smartphone,
  X,
  Menu
} from 'lucide-react';
import Brick3D from './components/Brick3D';
import StackGame from './components/StackGame';
import NewsFeed from './components/NewsFeed';
import CustomizeSection from './components/CustomizeSection';
import IndestructibilityTest from './components/IndestructibilityTest';
import { CustomizationState } from './types';
import { ambientResonance } from './utils/ambientAudio';

export default function App() {
  const [purchasedState, setPurchasedState] = useState<{
    custom: CustomizationState;
    price: number;
    serial: string;
  } | null>(null);

  const [activeSection, setActiveSection] = useState('hero');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const [isMuted, setIsMuted] = useState<boolean>(() => {
    const stored = localStorage.getItem('terra-ambient-muted');
    return stored !== null ? stored === 'true' : true;
  });

  // Keep ambient sound synchronized with state
  useEffect(() => {
    ambientResonance.setMute(isMuted);
    localStorage.setItem('terra-ambient-muted', String(isMuted));
  }, [isMuted]);

  // Handle click/touch interactions to resume context on mobile/desktop browsers
  useEffect(() => {
    const handleInteraction = () => {
      if (!isMuted) {
        ambientResonance.resumeOnInteraction();
      }
    };
    window.addEventListener('click', handleInteraction);
    window.addEventListener('touchstart', handleInteraction);
    return () => {
      window.removeEventListener('click', handleInteraction);
      window.removeEventListener('touchstart', handleInteraction);
    };
  }, [isMuted]);

  // Tracking active section via window scroll to highlight elegant nav dots
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['hero', 'philosophy', 'game', 'resilience', 'disruption', 'customize'];
      const scrollPos = window.scrollY + 250;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleAcquisitionSuccess = (custom: CustomizationState, finalPrice: number) => {
    const randomSerial = `BRK-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}-X`;
    setPurchasedState({
      custom,
      price: finalPrice,
      serial: randomSerial,
    });
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="bg-[#0D0D0D] text-[#E5E5E5] font-sans min-h-screen relative selection:bg-terracotta-500/30 selection:text-white">
      
      {/* Absolute clean crimson halo behind container (soft architectural ambience) */}
      <div className="absolute top-1/4 left-1/4 w-[400px] h-[400px] bg-terracotta-500/5 rounded-full filter blur-[150px] pointer-events-none -z-10" />
      <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-terracotta-500/5 rounded-full filter blur-[180px] pointer-events-none -z-10" />

      {/* Elegant Nav Dots for VIP client navigation */}
      <div className="fixed right-6 top-1/2 -translate-y-1/2 z-40 hidden md:flex flex-col gap-4 items-center">
        {[
          { id: 'hero', label: 'Home' },
          { id: 'philosophy', label: 'About Brick' },
          { id: 'game', label: 'Brick Game' },
          { id: 'resilience', label: 'Strength Test' },
          { id: 'disruption', label: 'Create News' },
          { id: 'customize', label: 'Buy Brick' },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => scrollToSection(item.id)}
            className="group flex items-center gap-3 relative focus:outline-none"
          >
            <span className="text-[9px] font-mono tracking-[0.2em] uppercase opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-terracotta-500">
              {item.label}
            </span>
            <span
              className={`w-2 h-2 rounded-full border transition-all duration-300 ${
                activeSection === item.id
                  ? 'bg-terracotta-500 border-terracotta-500 scale-125'
                  : 'bg-transparent border-white/20 group-hover:border-white/40'
              }`}
            />
          </button>
        ))}
      </div>

      {/* Pristine Header Nav */}
      <nav className="sticky top-0 z-50 border-b border-white/5 bg-[#0D0D0D]/85 backdrop-blur-md px-4 md:px-12 py-5 transition-all duration-300">
        <div className="max-w-7xl mx-auto flex items-center justify-between relative">
          
          {/* Left Side: Logo & Mobile Menu Trigger */}
          <div className="flex items-center gap-4">
            {/* Mobile Menu Icon (hidden on desktop) */}
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} 
              className="lg:hidden p-2 text-neutral-400 hover:text-white transition-colors focus:outline-none focus:ring-0 cursor-pointer"
              aria-label="Toggle Navigation Menu"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            {/* Brand Identity - Perfectly centered on mobile, sits elegantly on the left for desktop with balanced visual tracking */}
            <div 
              onClick={() => {
                scrollToSection('hero');
                setIsMobileMenuOpen(false);
              }} 
              className="lg:static absolute left-1/2 lg:left-auto lg:translate-x-0 -translate-x-1/2 text-lg md:text-2xl tracking-[0.5em] md:tracking-[0.7em] pl-[0.5em] md:pl-[0.7em] font-light italic cursor-pointer select-none text-white transition-opacity hover:opacity-80 z-10"
            >
              KAWSAR
            </div>
          </div>

          {/* Center: Desktop Nav Links (perfectly spaced, no clashing) */}
          <div className="hidden lg:flex items-center gap-6 xl:gap-8 text-[9px] md:text-[10px] uppercase tracking-[0.25em] font-bold mx-auto">
            {[
              { id: 'philosophy', label: 'Inside the Brick' },
              { id: 'game', label: 'Play Brick Game' },
              { id: 'resilience', label: 'Strength Test' },
              { id: 'disruption', label: 'Create News Story' },
            ].map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`relative py-1.5 transition-all duration-300 cursor-pointer ${
                    isActive ? 'text-terracotta-500 font-extrabold' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <motion.span 
                      layoutId="navActiveLine"
                      className="absolute bottom-0 left-0 right-0 h-[2px] bg-terracotta-500 rounded-full"
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    />
                  )}
                </button>
              );
            })}
          </div>

          {/* Right: Sound Control & Direct Acquisition CTA */}
          <div className="flex items-center gap-3 md:gap-6 text-[9px] md:text-[10px] uppercase tracking-[0.25em] font-bold">
            {/* Resonance Toggle with state */}
            <button 
              onClick={() => setIsMuted(!isMuted)} 
              className="flex items-center gap-2 text-neutral-400 hover:text-white transition-colors py-2 px-1 focus:outline-none cursor-pointer"
              title={isMuted ? "Activate Grounding Resonance Ambient Sound" : "Mute Grounding Resonance Ambient Sound"}
            >
              <div className="relative flex items-center justify-center w-5 h-5 rounded-full border border-white/10 bg-black/40">
                {isMuted ? (
                  <VolumeX className="w-3 h-3 text-neutral-500" />
                ) : (
                  <>
                    <Volume2 className="w-3 h-3 text-terracotta-500 animate-pulse" />
                    <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-terracotta-500 animate-ping" />
                  </>
                )}
              </div>
              <span className="hidden sm:inline font-mono tracking-widest text-[8px] text-neutral-400">
                {isMuted ? "SOUND: OFF" : "SOUND: ON"}
              </span>
            </button>

            <span className="opacity-40 hidden xl:inline text-[9px] tracking-widest font-mono">004 / 100</span>

            <button 
              onClick={() => {
                scrollToSection('customize');
                setIsMobileMenuOpen(false);
              }} 
              className="text-terracotta-500 hover:text-red-400 transition-colors py-2 cursor-pointer border border-terracotta-500/20 px-3 bg-terracotta-500/[0.03] hover:bg-terracotta-500/[0.08]"
            >
              Customize & Buy
            </button>
          </div>

        </div>

        {/* Elegant Mobile Navigation Panel Drawer with slide-down drop effect */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
              className="lg:hidden overflow-hidden bg-black/45 backdrop-blur-lg border-t border-white/5 mt-4"
            >
              <div className="flex flex-col gap-5 py-6 px-4">
                {[
                  { id: 'hero', number: '01', label: 'Home Screen' },
                  { id: 'philosophy', number: '02', label: 'Inside the Brick' },
                  { id: 'game', number: '03', label: 'Brick Stacking Game' },
                  { id: 'resilience', number: '04', label: 'Brick Strength Test' },
                  { id: 'disruption', number: '05', label: 'Create News Story' },
                  { id: 'customize', number: '06', label: 'Customize & Order' },
                ].map((item) => {
                  const isActive = activeSection === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        scrollToSection(item.id);
                        setIsMobileMenuOpen(false);
                      }}
                      className="flex items-center gap-4 text-left group focus:outline-none py-1.5 cursor-pointer w-full"
                    >
                      <span className={`font-mono text-[10px] tracking-widest ${
                        isActive ? 'text-terracotta-500 font-extrabold' : 'text-neutral-500'
                      }`}>
                        {item.number} //
                      </span>
                      <span className={`text-[11px] md:text-xs uppercase tracking-[0.25em] font-serif transition-colors ${
                        isActive ? 'text-terracotta-500 font-extrabold' : 'text-neutral-400 group-hover:text-white'
                      }`}>
                        {item.label}
                      </span>
                      {isActive && (
                        <span className="w-1.5 h-1.5 rounded-full bg-terracotta-500 animate-pulse ml-auto" />
                      )}
                    </button>
                  );
                })}

                {/* Ambient Sound control explicitly visible and simple inside Mobile Menu */}
                <div className="pt-4 border-t border-white/5 flex items-center justify-between">
                  <span className="font-mono text-[8px] tracking-[0.3em] uppercase text-neutral-500">
                    Ambient Environment Sound
                  </span>
                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className={`flex items-center gap-2 px-3 py-1.5 border font-mono text-[8px] tracking-widest cursor-pointer transition-all ${
                      !isMuted 
                        ? 'border-terracotta-500 bg-terracotta-500/15 text-terracotta-500 font-bold' 
                        : 'border-white/10 bg-white/[0.02] text-neutral-400'
                    }`}
                  >
                    {!isMuted ? 'RESONANCE ACTIVE' : 'RESONANCE MUTED'}
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Main Single Page Sections */}
      <main className="px-6 md:px-12 max-w-7xl mx-auto space-y-32 md:space-y-44 pb-24 pt-8">
        
        {/* SECTION 1: HERO / EPITOME */}
        <section id="hero" className="min-h-[calc(100vh-140px)] flex flex-col lg:flex-row items-stretch justify-center gap-0 border border-white/10 rounded-sm overflow-hidden bg-black/20">
          
          {/* Left Pane: Product Display */}
          <div className="w-full lg:w-3/5 relative flex flex-col items-center justify-center p-8 md:p-12 border-b lg:border-b-0 lg:border-r border-white/10 min-h-[400px]">
            
            {/* Watermark "001" Background */}
            <div className="absolute top-8 left-12 select-none pointer-events-none">
              <div className="text-[140px] md:text-[220px] font-serif italic text-white/[0.03] leading-none">001</div>
            </div>

            {/* Glowing Red Halo */}
            <div className="absolute -inset-8 bg-terracotta-500/10 blur-3xl rounded-full pointer-events-none"></div>

            {/* Interactive 3D view with Elegant Floating Brick Effect */}
            <motion.div 
              animate={{ y: [-8, 8, -8] }}
              transition={{
                duration: 5,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="relative z-10 py-6 cursor-pointer"
            >
              <Brick3D finish="classic" engraving="LE BRK" />
            </motion.div>

            {/* Instruction tooltip */}
            <div className="absolute top-4 right-4 bg-[#0D0D0D]/80 backdrop-blur-md px-3 py-1 border border-white/10 text-center font-mono text-[8px] uppercase tracking-widest text-neutral-400">
              Drag to Rotate Brick
            </div>

            {/* Material Profile metadata info at bottom */}
            <div className="absolute bottom-6 left-6 md:left-12 flex flex-col gap-1 text-left z-10">
              <div className="text-[8px] font-mono uppercase tracking-[0.2em] text-white/40">Brick Material</div>
              <div className="text-[10px] md:text-xs tracking-[0.25em] font-mono text-white/90">REAL BAKED CLAY / 2.3KG</div>
            </div>
          </div>

          {/* Right Pane: Configuration & Narrative */}
          <div className="w-full lg:w-2/5 flex flex-col justify-between p-8 md:p-12 space-y-8 bg-white/[0.02]">
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 px-2.5 py-0.5 bg-white/5 border border-white/10">
                <Sparkles className="w-3 h-3 text-terracotta-500" />
                <span className="text-[8px] font-mono tracking-widest text-neutral-400 uppercase">
                  Premium Brick No. 01
                </span>
              </div>

              <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif text-white leading-[1.05] tracking-tight uppercase">
                The Red<br/><span className="italic text-terracotta-500">Brick.</span>
              </h1>

              <p className="text-xs md:text-sm text-neutral-400 leading-relaxed font-serif max-w-sm">
                The singular essential. A beautiful piece of solid mass, form, and absolute silence. It doesn't connect to Wi-Fi. It has zero pixels. It has exactly the physical weight you need to decorate your space.
              </p>

              <div className="grid grid-cols-3 gap-2 border-t border-b border-white/10 py-4 font-mono text-[9px] uppercase tracking-wider text-neutral-500">
                <div>
                  <span className="block text-[7px] text-white/30 mb-0.5">Weight</span>
                  <span className="text-white font-medium">4.3 lbs</span>
                </div>
                <div>
                  <span className="block text-[7px] text-white/30 mb-0.5">Firmware</span>
                  <span className="text-white font-medium">0.0 v</span>
                </div>
                <div>
                  <span className="block text-[7px] text-white/30 mb-0.5">Charge</span>
                  <span className="text-white font-medium">∞ Solid</span>
                </div>
              </div>
            </div>

            {/* Interactive Module: The Acoustic Density Simulator Feed */}
            <div className="bg-white/5 p-5 border border-white/10 rounded-sm">
              <div className="flex justify-between items-center mb-5">
                <span className="text-[8px] font-mono uppercase tracking-[0.2em] text-white/60">Sound Test</span>
                <span className="text-terracotta-500 text-[8px] font-mono tracking-widest flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-terracotta-500 animate-pulse inline-block" />
                  LIVE SIGNAL
                </span>
              </div>
              
              {/* Dynamic Sound bars simulation */}
              <div className="h-16 flex items-end gap-1.5 px-1">
                {[25, 45, 15, 80, 50, 30, 65, 40, 20, 75, 35].map((h, i) => (
                  <motion.div
                    key={i}
                    animate={{
                      height: [`${h}%`, `${Math.max(10, h + (i % 2 === 0 ? 15 : -15))}%`, `${h}%`]
                    }}
                    transition={{
                      duration: 1.5 + (i * 0.1),
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                    className={`flex-1 transition-colors duration-300 ${
                      i === 3 ? 'bg-terracotta-500' : 'bg-white/10'
                    }`}
                  />
                ))}
              </div>
              <div className="mt-3 text-[8px] font-mono uppercase tracking-widest text-white/40">
                Solid sound testing complete.
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-white/5">
              <div className="flex justify-between items-end">
                <div>
                  <div className="text-[8px] font-mono uppercase tracking-[0.2em] text-white/40 mb-1">Price</div>
                  <div className="text-xl md:text-2xl font-light tracking-widest text-white">$14,500.00</div>
                </div>
                <div className="text-[8px] font-mono tracking-widest text-terracotta-500 uppercase font-semibold">
                  Available to Buy
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-2">
                <button
                  onClick={() => scrollToSection('customize')}
                  className="flex-1 py-4 bg-[#E5E5E5] text-[#0D0D0D] text-[9px] font-bold uppercase tracking-[0.4em] hover:bg-white active:scale-[0.98] transition-all rounded-sm flex items-center justify-center gap-2"
                >
                  Customize & Buy
                </button>
                <button
                  onClick={() => scrollToSection('game')}
                  className="py-4 px-5 bg-white/5 hover:bg-white/10 text-white border border-white/10 text-[9px] font-bold uppercase tracking-[0.3em] active:scale-[0.98] transition-all rounded-sm"
                >
                  Play Game
                </button>
              </div>
            </div>

          </div>

        </section>

        {/* SECTION 2: THE ANATOMY OF PERFECTION */}
        <motion.section 
          id="philosophy" 
          initial={{ opacity: 0, y: 45 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="scroll-mt-24 space-y-12"
        >
          <div className="text-center max-w-xl mx-auto space-y-3">
            <span className="text-[10px] font-mono text-terracotta-500 uppercase tracking-[0.25em]">
              Section 01 // Why Buy a Brick?
            </span>
            <h2 className="text-3xl md:text-4xl font-serif text-white tracking-wide uppercase">
              Why Choose Our Brick?
            </h2>
            <p className="text-xs text-neutral-400 font-serif leading-relaxed">
              In a world full of screens, phones, and constant notifications, our simple brick offers a unique choice: 100% pure, quiet, and solid peace.
            </p>
          </div>

          {/* Bento-style grid of satirical luxury benefits */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            
            <div className="bg-[#0D0D0D]/60 p-6 rounded-sm border border-white/10 flex flex-col justify-between h-56 group hover:border-white/20 transition-all duration-300">
              <div className="w-10 h-10 bg-terracotta-950/40 border border-terracotta-500/25 rounded-sm flex items-center justify-center text-terracotta-500">
                <ZapOff className="w-5 h-5" />
              </div>
              <div className="space-y-1.5">
                <h4 className="text-xs font-mono text-white uppercase tracking-widest font-bold">0.0 Pixels Display</h4>
                <p className="text-[11px] text-neutral-400 font-serif leading-relaxed">
                  Never suffer from blue-light exhaustion again. High-contrast baked terracotta provides 100% optical relaxation.
                </p>
              </div>
            </div>

            <div className="bg-[#0D0D0D]/60 p-6 rounded-sm border border-white/10 flex flex-col justify-between h-56 group hover:border-white/20 transition-all duration-300">
              <div className="w-10 h-10 bg-neutral-950/40 border border-terracotta-500/25 rounded-sm flex items-center justify-center text-terracotta-500">
                <VolumeX className="w-5 h-5" />
              </div>
              <div className="space-y-1.5">
                <h4 className="text-xs font-mono text-white uppercase tracking-widest font-bold">100% Noise Suppression</h4>
                <p className="text-[11px] text-neutral-400 font-serif leading-relaxed">
                  No ringer, no notifications, no alarm clock. Complete absolute acoustic tranquility guaranteed across all environments.
                </p>
              </div>
            </div>

            <div className="bg-[#0D0D0D]/60 p-6 rounded-sm border border-white/10 flex flex-col justify-between h-56 group hover:border-white/20 transition-all duration-300">
              <div className="w-10 h-10 bg-emerald-950/40 border border-emerald-500/25 rounded-sm flex items-center justify-center text-emerald-500">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="space-y-1.5">
                <h4 className="text-xs font-mono text-white uppercase tracking-widest font-bold">Analog Encryption Core</h4>
                <p className="text-[11px] text-neutral-400 font-serif leading-relaxed">
                  Stores 0 bytes of metadata. Impervious to ransomware, spyware, global malware, or database leakages.
                </p>
              </div>
            </div>

            <div className="bg-[#0D0D0D]/60 p-6 rounded-sm border border-white/10 flex flex-col justify-between h-56 group hover:border-white/20 transition-all duration-300">
              <div className="w-10 h-10 bg-yellow-950/40 border border-terracotta-500/25 rounded-sm flex items-center justify-center text-yellow-600">
                <Layers className="w-5 h-5" />
              </div>
              <div className="space-y-1.5">
                <h4 className="text-xs font-mono text-white uppercase tracking-widest font-bold">Environmental Fusion</h4>
                <p className="text-[11px] text-neutral-400 font-serif leading-relaxed">
                  Naturally absorbs room moisture. Gradually acquires a stunning weathered organic moss patina in high-humidity luxury quarters.
                </p>
              </div>
            </div>

          </div>
        </motion.section>

        {/* SECTION 3: BRK-STK MINI-GAME */}
        <motion.section 
          id="game" 
          initial={{ opacity: 0, y: 45 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="scroll-mt-24 space-y-8"
        >
          <div className="text-center max-w-xl mx-auto space-y-3">
            <span className="text-[10px] font-mono text-terracotta-500 uppercase tracking-[0.25em]">
              Section 02 // Play Fun Mini-Game
            </span>
            <h2 className="text-3xl md:text-4xl font-serif text-white tracking-wide uppercase">
              Brick Stacking Game
            </h2>
            <p className="text-xs text-neutral-400 font-serif leading-relaxed">
              Test your focus! Tap to stack bricks perfectly on top of each other. Try to build the highest tower without dropping any parts.
            </p>
          </div>

          <StackGame />
        </motion.section>

        {/* SECTION 4: TEST THE INDESTRUCTIBILITY */}
        <motion.section 
          id="resilience" 
          initial={{ opacity: 0, y: 45 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="scroll-mt-24 space-y-8"
        >
          <div className="text-center max-w-xl mx-auto space-y-3">
            <span className="text-[10px] font-mono text-terracotta-500 uppercase tracking-[0.25em]">
              Section 03 // Hit the Brick Test
            </span>
            <h2 className="text-3xl md:text-4xl font-serif text-white tracking-wide uppercase">
              Test Brick Strength
            </h2>
            <p className="text-xs text-neutral-400 font-serif leading-relaxed">
              Try different heavy tools to strike the brick and see if you can break it! Our solid brick is 100% strong and cannot be broken.
            </p>
          </div>

          <IndestructibilityTest />
        </motion.section>

        {/* SECTION 5: DISRUPTION MAGAZINE - PERSONALIZED PRESS */}
        <motion.section 
          id="disruption" 
          initial={{ opacity: 0, y: 45 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="scroll-mt-24 space-y-8"
        >
          <div className="text-center max-w-xl mx-auto space-y-3">
            <span className="text-[10px] font-mono text-terracotta-500 uppercase tracking-[0.25em]">
              Section 04 // Personalized Story Generator
            </span>
            <h2 className="text-3xl md:text-4xl font-serif text-white tracking-wide uppercase">
              Create Custom News Story
            </h2>
            <p className="text-xs text-neutral-400 font-serif leading-relaxed">
              Type your name to generate a fun custom newspaper or magazine story about your brick! Our smart system creates a personalized article instantly.
            </p>
          </div>

          <NewsFeed />
        </motion.section>

        {/* SECTION 6: BESPOKE CUSTOMIZER */}
        <motion.section 
          id="customize" 
          initial={{ opacity: 0, y: 45 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="scroll-mt-24 space-y-8"
        >
          <div className="text-center max-w-xl mx-auto space-y-3">
            <span className="text-[10px] font-mono text-terracotta-500 uppercase tracking-[0.25em]">
              Section 05 // Create Your Custom Brick
            </span>
            <h2 className="text-3xl md:text-4xl font-serif text-white tracking-wide uppercase">
              Customize & Order
            </h2>
            <p className="text-xs text-neutral-400 font-serif leading-relaxed">
              Customize your brick to fit your style! Choose your favorite material (Classic Clay, Black Obsidian, or Luxury Gold), write a custom name, and place your order.
            </p>
          </div>

          <CustomizeSection onSuccessBuy={handleAcquisitionSuccess} />
        </motion.section>

      </main>

      {/* BOTTOM BRANDING BAR (Signature Geometric Balance Strip) */}
      <div className="h-14 bg-[#E5E5E5] text-[#0D0D0D] flex flex-col md:flex-row items-center justify-between px-6 md:px-12 py-3 md:py-0 border-t border-b border-white/10 select-none font-mono text-[9px] font-bold uppercase tracking-[0.3em] gap-2">
        <div>
          Brick 01 / Red / Architectural Standard / 2026 Collection
        </div>
        <div className="flex gap-6 md:gap-12">
          <span className="opacity-50">© 2026 Terra Monolith Corp.</span>
          <span className="underline decoration-1 underline-offset-4">Authenticity Certificate Included</span>
        </div>
      </div>

      {/* FOOTER */}
      <footer className="border-t border-white/10 bg-[#070707] px-6 py-12 md:px-12 text-center text-neutral-500 text-xs">
        <div className="max-w-7xl mx-auto space-y-4">
          <div className="flex items-center justify-center gap-2">
            <Compass className="w-4 h-4 text-neutral-500" />
            <span className="text-sm font-serif font-bold tracking-[0.2em] text-white uppercase">LE BRK</span>
          </div>
          <p className="max-w-md mx-auto leading-relaxed text-[10px] font-mono">
            MSRP starting at $14,500 USD. Le BRK has zero battery, zero display, zero microprocessors, zero storage, and produces zero emissions or lights. It is solid clay. Placing it on highly expensive desks may cause severe intimidation to colleagues. Use with absolute structural prudence.
          </p>
          <div className="border-t border-neutral-900/60 pt-4 flex flex-col sm:flex-row items-center justify-between text-[10px] font-mono gap-2 text-neutral-500">
            <span>© 2026 LE BRK, INC. ALL ARISTOCRATIC HEGEMONY SECURED.</span>
            <div className="flex gap-4">
              <span className="cursor-pointer hover:text-white transition-colors">PRIVACY REGISTRY</span>
              <span className="cursor-pointer hover:text-white transition-colors">WHITE-GLOVE CODE</span>
              <span className="cursor-pointer hover:text-white transition-colors">KILN LICENSING</span>
            </div>
          </div>
        </div>
      </footer>

      {/* CERTIFICATE OF MONOLITH ACQUISITION SUCCESS MODAL */}
      <AnimatePresence>
        {purchasedState && (
          <div className="fixed inset-0 bg-black/95 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, y: 30, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 30, opacity: 0 }}
              className="bg-[#E5E5E5] text-[#0D0D0D] max-w-xl w-full rounded-none border-2 border-[#0D0D0D] shadow-2xl p-6 md:p-8 relative my-8"
            >
              <button
                onClick={() => setPurchasedState(null)}
                className="absolute top-4 right-4 text-stone-600 hover:text-stone-900 transition-colors bg-[#0D0D0D]/5 p-1.5"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="text-center space-y-2 border-b border-dashed border-stone-400 pb-5">
                <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-terracotta-700 font-bold block">
                  ♛ High Society Registry Certificate ♛
                </span>
                <h3 className="text-2xl md:text-3xl font-serif tracking-tight font-extrabold uppercase text-stone-900">
                  DEED OF ACQUISITION
                </h3>
                <span className="inline-block bg-stone-200 px-3 py-1 rounded text-[10px] font-mono font-bold uppercase tracking-wider text-stone-700">
                  Serial Number: {purchasedState.serial}
                </span>
              </div>

              <div className="py-6 space-y-4 font-serif text-sm leading-relaxed text-stone-800">
                <p className="text-center font-medium italic">
                  "Let it be known to all sovereigns and designer circles that the elite custom clay monolith detailed below has been formally allocated."
                </p>

                <div className="grid grid-cols-2 gap-4 bg-stone-100 p-4 rounded-xl border border-stone-200 font-sans text-xs">
                  <div>
                    <span className="block text-[8px] font-mono text-stone-500 uppercase">Monolith Skin Finish:</span>
                    <span className="font-semibold text-stone-900 uppercase">{purchasedState.custom.finish}</span>
                  </div>
                  <div>
                    <span className="block text-[8px] font-mono text-stone-500 uppercase">Custom Surface Engraving:</span>
                    <span className="font-semibold text-stone-900 uppercase italic">"{purchasedState.custom.engraving || 'Raw purist'}"</span>
                  </div>
                  <div>
                    <span className="block text-[8px] font-mono text-stone-500 uppercase">Preservation Accessories:</span>
                    <span className="font-semibold text-stone-900">
                      {[
                        purchasedState.custom.velvetStand ? 'Velvet Stand' : null,
                        purchasedState.custom.organicMossStarter ? 'Moss Spores' : null,
                      ].filter(Boolean).join(', ') || 'None'}
                    </span>
                  </div>
                  <div>
                    <span className="block text-[8px] font-mono text-stone-500 uppercase">Secured Capital Value:</span>
                    <span className="font-semibold text-stone-900 font-mono">${purchasedState.price.toLocaleString()} USD</span>
                  </div>
                </div>

                <div className="pt-4 flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left border-t border-dashed border-stone-200">
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-terracotta-700 shrink-0" />
                    <div>
                      <span className="block text-[8px] font-mono uppercase text-stone-500 leading-none">White-Glove Courier Dispatch</span>
                      <span className="block text-[11px] font-sans font-bold text-stone-900">Inbound via private helicopter in 48 hours</span>
                    </div>
                  </div>
                  <div className="text-center md:text-right border-t md:border-t-0 border-stone-200 pt-3 md:pt-0 w-full md:w-auto">
                    <span className="block text-[9px] font-mono text-stone-500 uppercase tracking-widest leading-none mb-1">Signed & Kiln-Fired by:</span>
                    <span className="font-serif italic font-bold text-stone-900 text-lg">Sir Claymore Kiln</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setPurchasedState(null)}
                className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-white font-mono text-xs uppercase tracking-widest rounded-lg font-bold"
              >
                Conclude Allocation Deed
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
