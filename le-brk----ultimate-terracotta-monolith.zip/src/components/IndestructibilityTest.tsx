import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Hammer, Zap, Shield, CircleDot } from 'lucide-react';
import { ambientResonance } from '../utils/ambientAudio';

interface Particle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  life: number;
}

interface LogEntry {
  id: string;
  time: string;
  parameter: string;
  status: 'UNDAMAGED' | 'STABLE' | 'OPTIMAL';
}

export default function IndestructibilityTest() {
  const [activeTool, setActiveTool] = useState<'hammer' | 'laser' | 'drill'>('hammer');
  const [counter, setCounter] = useState(0);
  const [isStriking, setIsStriking] = useState(false);
  const [isToolChanging, setIsToolChanging] = useState(false);
  const [showDeclaration, setShowDeclaration] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const brickRef = useRef<HTMLDivElement | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const animationFrameRef = useRef<number | null>(null);

  // Trigger shatter-proof scale-up pulse when tool changes
  useEffect(() => {
    setIsToolChanging(true);
    const timer = setTimeout(() => setIsToolChanging(false), 500);
    return () => clearTimeout(timer);
  }, [activeTool]);

  const tools = [
    {
      id: 'hammer' as const,
      name: 'Pneumatic Hammer',
      desc: '15,000 Newtons of concentrated force.',
      icon: Hammer,
      particleColor: '#B22222',
      impactForce: '15.2 kN',
    },
    {
      id: 'laser' as const,
      name: 'Class-IV Thermal Laser',
      desc: '3,200°C focused infrared beam.',
      icon: Zap,
      particleColor: '#FF4500',
      impactForce: '8.4 GW/cm²',
    },
    {
      id: 'drill' as const,
      name: 'Diamond-Tipped Corer',
      desc: '10,000 RPM diamond abrasion.',
      icon: CircleDot,
      particleColor: '#e5e5e5',
      impactForce: '98.5 GPa',
    },
  ];

  // Initialize logs on load
  useEffect(() => {
    const formatTime = (date: Date) => {
      return date.toTimeString().split(' ')[0] + '.' + String(date.getMilliseconds()).padStart(3, '0');
    };
    
    const now = new Date();
    const t1 = new Date(now.getTime() - 24000);
    const t2 = new Date(now.getTime() - 12000);
    
    setLogs([
      {
        id: 'init-1',
        time: formatTime(now),
        parameter: 'BRICK STRENGTH NOMINAL // NO CRACKS FOUND',
        status: 'OPTIMAL',
      },
      {
        id: 'init-2',
        time: formatTime(t2),
        parameter: 'BRICK SOLID MASS AT EQUILIBRIUM',
        status: 'STABLE',
      },
      {
        id: 'init-3',
        time: formatTime(t1),
        parameter: 'BRICK MEASUREMENT CALIBRATED',
        status: 'OPTIMAL',
      },
    ]);
  }, []);

  // Particle simulation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize canvas to cover container
    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = rect.height;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const updateAndDraw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const particles = particlesRef.current;

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.15; // subtle gravity
        p.life -= 1;
        p.alpha = Math.max(0, p.life / 40);

        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();

        if (p.life <= 0) {
          particles.splice(i, 1);
        }
      }
      ctx.globalAlpha = 1.0;

      animationFrameRef.current = requestAnimationFrame(updateAndDraw);
    };

    updateAndDraw();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, []);

  const handleImpact = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isStriking) return;
    setIsStriking(true);
    setCounter((prev) => prev + 1);

    const tool = tools.find((t) => t.id === activeTool)!;
    const color = tool.particleColor;

    // Spawn sparks/particles on current coordinates relative to the canvas
    const canvas = canvasRef.current;
    if (canvas) {
      const rect = canvas.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const clickY = e.clientY - rect.top;

      const count = activeTool === 'laser' ? 35 : 20;
      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 5 + 2;
        particlesRef.current.push({
          id: Math.random(),
          x: clickX,
          y: clickY,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 1.5, // upwards bias
          color: color,
          size: Math.random() * 3.5 + 1.5,
          alpha: 1.0,
          life: Math.random() * 25 + 15,
        });
      }
    }

    // Append a live telemetry log
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0] + '.' + String(now.getMilliseconds()).padStart(3, '0');
    const newEntry: LogEntry = {
      id: Math.random().toString(),
      time: timeStr,
      parameter: `STRIKE ATTEMPT #${counter + 1}: ${tool.name.toUpperCase()} [${tool.impactForce}]`,
      status: 'UNDAMAGED',
    };
    
    setLogs((prev) => [newEntry, ...prev].slice(0, 3));

    // Reset strike animation trigger
    setTimeout(() => {
      setIsStriking(false);
    }, 150);

    // Dynamic quote/toast sometimes on high numbers
    if ((counter + 1) % 15 === 0) {
      setShowDeclaration(true);
      ambientResonance.playSuccessPing();
      setTimeout(() => setShowDeclaration(false), 2500);
    }
  };

  const selectedTool = tools.find((t) => t.id === activeTool)!;

  return (
    <div className="w-full bg-[#0D0D0D] border border-white/10 rounded-none p-6 md:p-10 text-white relative overflow-hidden">
      
      {/* Visual background lines to match grid */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
           style={{ backgroundImage: 'radial-gradient(white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch relative z-10">
        
        {/* Left column: Tool selector & statistics panel */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <span className="text-[10px] font-mono text-terracotta-500 uppercase tracking-[0.2em] block">
              Simulation Module 05
            </span>
            <h3 className="text-2xl md:text-3xl font-serif text-white tracking-wide font-light uppercase">
              TEST BRICK STRENGTH
            </h3>
            <p className="text-xs text-neutral-400 font-serif leading-relaxed max-w-sm">
              Click the brick to test its strength with different tools. Try to strike or hit it. Our solid brick will stay 100% strong without breaking!
            </p>
          </div>

          {/* Selector options */}
          <div className="space-y-3.5">
            <span className="block text-[8px] font-mono text-neutral-500 uppercase tracking-widest">
              Select a Tool to Hit the Brick
            </span>
            <div className="grid grid-cols-1 gap-2.5">
              {tools.map((tool) => {
                const Icon = tool.icon;
                return (
                  <button
                    key={tool.id}
                    onClick={() => setActiveTool(tool.id)}
                    className={`flex items-center justify-between p-3.5 border text-left transition-all rounded-none cursor-pointer ${
                      activeTool === tool.id
                        ? 'border-terracotta-500 bg-terracotta-500/10 text-white'
                        : 'border-white/10 bg-black/20 text-neutral-400 hover:border-white/30'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className={`w-4 h-4 ${activeTool === tool.id ? 'text-terracotta-500' : 'text-neutral-500'}`} />
                      <div>
                        <span className="block text-xs font-mono font-bold tracking-wider uppercase">{tool.name}</span>
                        <span className="block text-[9px] text-neutral-500 leading-tight mt-0.5">{tool.desc}</span>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-wider">{tool.impactForce}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Counters and integrity display */}
          <div className="grid grid-cols-2 gap-4 border-t border-white/10 pt-6">
            <div>
              <span className="block text-[8px] font-mono text-neutral-500 uppercase tracking-widest mb-1">
                Total Strikes Applied
              </span>
              <span className="text-2xl font-mono text-white font-bold tracking-wider">
                {counter.toLocaleString()}
              </span>
            </div>
            <div>
              <span className="block text-[8px] font-mono text-neutral-500 uppercase tracking-widest mb-1">
                Brick Strength Left
              </span>
              <span className="text-2xl font-mono text-terracotta-500 font-bold tracking-wider">
                100.00%
              </span>
            </div>
          </div>
        </div>

        {/* Right column: Interactive brick testbed */}
        <div className="lg:col-span-7 bg-black/40 border border-white/10 p-6 flex flex-col justify-between relative min-h-[400px]">
          
          <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-10 pointer-events-none">
            <span className="text-[8px] font-mono uppercase tracking-[0.2em] text-white/40">
              Live Strength Monitor Readout
            </span>
            <span className="text-[8px] font-mono tracking-widest text-terracotta-500 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-terracotta-500 animate-pulse" />
              STRENGTH_MONITOR_ACTIVE
            </span>
          </div>

          {/* Canvas particle background overlay */}
          <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none z-10" />

          {/* Interactive target container */}
          <div 
            ref={brickRef}
            onClick={handleImpact}
            className="flex-1 flex flex-col items-center justify-center cursor-pointer relative select-none group mt-6"
          >
            {/* The Indestructible Brick Object */}
            <motion.div
              animate={isStriking ? {
                scale: [1, 0.95, 1.02, 1],
                rotate: activeTool === 'hammer' ? [-1.5, 1.5, 0] : [0, 0, 0],
                y: activeTool === 'hammer' ? [0, 5, -1, 0] : [0, 0, 0],
              } : isToolChanging ? {
                scale: [1, 1.04, 0.98, 1],
              } : {}}
              transition={isStriking ? { duration: 0.15, ease: "easeOut" } : { duration: 0.4, ease: "easeInOut" }}
              className={`relative w-80 h-40 bg-[#8B0000] shadow-[0_20px_50px_rgba(0,0,0,0.8)] border border-white/5 overflow-hidden transition-all duration-300 ${
                activeTool === 'laser' && isStriking ? 'ring-1 ring-red-500/50' : ''
              }`}
            >
              {/* Texture detail simulation */}
              <div className="absolute inset-0 opacity-25" style={{ backgroundImage: 'radial-gradient(#000 1.2px, transparent 0)', backgroundSize: '6px 6px' }} />
              <div className="absolute top-0 left-0 w-full h-2.5 bg-white/10" />
              <div className="absolute bottom-0 right-0 w-3 h-full bg-black/40" />
              <div className="absolute top-4 left-4 text-[7px] font-mono uppercase tracking-widest text-white/30">
                KAWSAR BRICK CORE
              </div>

              {/* Shatter-Proof status active display */}
              <AnimatePresence>
                {isToolChanging && (
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    transition={{ duration: 0.25 }}
                    className="absolute bottom-3 left-4 flex items-center gap-1.5 z-20 pointer-events-none"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                    <span className="text-[7px] font-mono text-emerald-400 font-bold uppercase tracking-widest">
                      UNBREAKABLE STATE ACTIVE
                    </span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Protective Shield Outer Aura */}
              <AnimatePresence>
                {isToolChanging && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: [0, 0.3, 0], scale: [0.95, 1.08, 1.15] }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.45, ease: "easeOut" }}
                    className="absolute inset-0 border border-emerald-500/40 bg-emerald-500/[0.02] pointer-events-none z-20"
                  />
                )}
              </AnimatePresence>

              {/* Fake impact rings that light up briefly */}
              <AnimatePresence>
                {isStriking && (
                  <motion.div
                    initial={{ opacity: 0.8, scale: 0.8 }}
                    animate={{ opacity: 0, scale: 1.5 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.25 }}
                    className="absolute inset-0 flex items-center justify-center pointer-events-none"
                  >
                    <div className={`w-32 h-32 rounded-full border ${
                      activeTool === 'laser' ? 'border-orange-500' : 'border-red-600'
                    } opacity-40`} />
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>

            {/* Instruction hint */}
            <div className="absolute bottom-4 text-center pointer-events-none transition-opacity duration-300 group-hover:opacity-100 opacity-60">
              <span className="text-[9px] font-mono text-neutral-400 uppercase tracking-[0.2em]">
                {activeTool === 'hammer' ? 'Click brick to strike with Hammer' : 
                 activeTool === 'laser' ? 'Click brick to fire laser beam' : 
                 'Click brick to engage core drill'}
              </span>
            </div>
          </div>

          {/* Live telemetry feed of logs */}
          <div className="border-t border-white/10 pt-4 h-28 flex flex-col justify-end font-mono text-[9px] text-neutral-500 space-y-1 overflow-hidden pointer-events-none">
            <div className="flex justify-between border-b border-white/5 pb-1 text-white/40 uppercase">
              <span>Timestamp</span>
              <span>Test Action</span>
              <span>Brick Status</span>
            </div>
            
            {logs.map((log) => (
              <div key={log.id} className="flex justify-between items-center text-white/80 transition-all duration-300">
                <span>[{log.time}]</span>
                <span className="uppercase text-neutral-400 truncate max-w-[280px]">{log.parameter}</span>
                <span className={`font-bold uppercase ${
                  log.status === 'OPTIMAL' ? 'text-emerald-500/80' : 
                  log.status === 'STABLE' ? 'text-blue-400/80' : 'text-emerald-500'
                }`}>
                  {log.status}
                </span>
              </div>
            ))}
          </div>

        </div>

      </div>

      {/* Pop-up Award toast upon hitting increments */}
      <AnimatePresence>
        {showDeclaration && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute bottom-4 left-4 right-4 bg-white text-[#0D0D0D] p-3 border border-[#0D0D0D] z-30 flex items-center justify-between text-[10px] font-mono uppercase tracking-wider"
          >
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-terracotta-500" />
              <span>Safe Certification: No damage after {counter} strong hits.</span>
            </div>
            <span className="font-bold text-terracotta-500">100% Genuine Solid Clay</span>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}

