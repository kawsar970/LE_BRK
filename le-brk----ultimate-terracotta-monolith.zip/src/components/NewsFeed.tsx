import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Compass, BookOpen, Send, Sparkles, AlertCircle, Quote } from 'lucide-react';
import { NewsArticle } from '../types';

const ARCHETYPES = [
  { value: 'Silent Wealth Oligarch', label: 'Silent Wealth Oligarch', desc: 'You appreciate high-mass objects that command respect without flashing light.' },
  { value: 'Minimalist Architect', label: 'Minimalist Architect', desc: 'You believe walls should be plain clay, and tech should be non-electronic.' },
  { value: 'Avant-Garde Curator', label: 'Avant-Garde Curator', desc: 'You display industrial materials in glass cases to evoke existential dread.' },
  { value: 'Off-Grid Sovereign', label: 'Off-Grid Sovereign', desc: 'You hoard precious physical bricks to build protective bunkers against digital surveillance.' },
  { value: 'Crypto Philanthropist', label: 'Crypto Philanthropist', desc: 'You swap volatile meme coins for stable, high-gravity physical clay assets.' },
];

const PREMIUM_ADDONS = [
  { value: 'Solid Gold Dipping', label: 'Sovereign 24K Gold Dipping' },
  { value: 'Eau de Terre Perfume', label: 'Eau de Terre (Clay-kiln parfum coating)' },
  { value: 'Royal Moss Starter Pack', label: 'Royal Moss (Hand-grafted velvet lichen)' },
  { value: 'Mahogany Keepsake Chest', label: 'Mahogany Keepsake Chest (Felt lined)' },
];

export default function NewsFeed() {
  const [name, setName] = useState('');
  const [archetype, setArchetype] = useState('Silent Wealth Oligarch');
  const [addon, setAddon] = useState('Royal Moss Starter Pack');
  const [loading, setLoading] = useState(false);
  const [article, setArticle] = useState<NewsArticle | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/generate-news', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          archetype,
          premiumAddon: addon,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to synchronize with society database');
      }

      const data = await response.json();
      // If the backend returned { news: ... }, extract it. Otherwise use the object itself.
      const parsedArticle = data.news ? data.news : data;
      setArticle(parsedArticle);
      setLoading(false);
    } catch (err: any) {
      console.error(err);
      setError('Connection to London Society feed timed out. Rendering locally sourced print instead.');
      // Emergency local generation that is still very high-end
      setTimeout(() => {
        setArticle({
          headline: `${name.toUpperCase()} ACCLAIMED BY LONDON SOCIETY BOARDS`,
          subheading: `Prominent ${archetype} takes center stage by introducing raw clay aesthetics to St. James private clubs.`,
          date: 'JUNE 2026',
          location: 'Mayfair Enclave',
          content: [
            `In the elite tea rooms of Mayfair, a silent wave of astonishment has spread. ${name}, the celebrated ${archetype}, has formally snubbed modern visual gadgets by introducing a single raw, red terracotta block. Customized with '${addon}', the block stands as an impenetrable statement of financial mass and physical silence.`,
            `\"It does absolutely nothing, and that is why it is everything,\" declared Lord Sterling, admiring the brick's rough kiln-baked texture. \"No screens, no updates, no surveillance. In terms of high-society dominance, ${name} has effectively placed checkmate upon the digital age.\"`
          ],
          editorialQuote: 'A screen is just glass. A brick is the earth itself. Which one has more gravity?',
          insiderScore: '99.8% Aristocratic Hegemony'
        });
        setLoading(false);
      }, 800);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto bg-[#0D0D0D] rounded-none border border-white/10 p-6 md:p-8 text-neutral-200">
      
      {/* Decorative top strip */}
      <div className="border-b border-white/10 pb-4 mb-6 flex flex-col md:flex-row justify-between items-center text-center md:text-left gap-2">
        <div>
          <h2 className="text-2xl md:text-3xl font-serif tracking-tight font-light uppercase text-white flex items-center justify-center md:justify-start gap-2.5">
            <Compass className="w-5 h-5 text-terracotta-500 stroke-[1.5]" /> BRICK WORLD NEWS
          </h2>
          <p className="text-[9px] font-mono tracking-[0.2em] text-neutral-400 uppercase mt-1">
            LATEST FUN STORIES ABOUT OUR CUSTOMERS // FREE FOR ALL
          </p>
        </div>
        <div className="bg-white/5 px-3 py-1.5 rounded-none border border-white/10 text-right font-mono text-[9px] uppercase tracking-wider text-neutral-400">
          Story Creator: <span className="text-terracotta-500 font-bold animate-pulse">ONLINE</span>
        </div>
      </div>
 
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Side: Input Profiler Form */}
        <div className="lg:col-span-5 bg-white/[0.02] p-5 rounded-none border border-white/10">
          <div className="flex items-center gap-2 mb-4">
            <Search className="w-4 h-4 text-terracotta-500" />
            <h3 className="text-xs font-mono uppercase tracking-widest text-neutral-300 font-bold">Fill in Your Details</h3>
          </div>
          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                Enter Your Name
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Lady Victoria Vance"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-none px-3 py-2 text-xs font-serif text-white placeholder-neutral-700 focus:outline-none focus:border-terracotta-500"
              />
            </div>
 
            <div>
              <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                Choose Your Style/Role
              </label>
              <select
                value={archetype}
                onChange={(e) => setArchetype(e.target.value)}
                className="w-full bg-black/45 border border-white/10 rounded-none px-2.5 py-2 text-xs font-sans text-neutral-200 focus:outline-none focus:border-terracotta-500"
              >
                {ARCHETYPES.map((arch) => (
                  <option key={arch.value} value={arch.value} className="bg-[#0D0D0D]">
                    {arch.label}
                  </option>
                ))}
              </select>
              <p className="text-[10px] text-neutral-500 italic mt-1.5 font-serif leading-tight">
                {ARCHETYPES.find((a) => a.value === archetype)?.desc}
              </p>
            </div>
 
            <div>
              <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                Choose Brick Decoration
              </label>
              <select
                value={addon}
                onChange={(e) => setAddon(e.target.value)}
                className="w-full bg-black/45 border border-white/10 rounded-none px-2.5 py-2 text-xs font-sans text-neutral-200 focus:outline-none focus:border-terracotta-500"
              >
                {PREMIUM_ADDONS.map((add) => (
                  <option key={add.value} value={add.value} className="bg-[#0D0D0D]">
                    {add.label}
                  </option>
                ))}
              </select>
            </div>
 
            <button
              type="submit"
              disabled={loading || !name.trim()}
              className="w-full flex items-center justify-center gap-2 px-5 py-3.5 bg-white text-[#0D0D0D] font-mono text-[9px] uppercase tracking-[0.3em] font-bold rounded-none transition-all active:scale-[0.98] disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <>
                  <Sparkles className="w-3.5 h-3.5 animate-spin text-terracotta-500" />
                  Creating your story...
                </>
              ) : (
                <>
                  <Send className="w-3 h-3 text-[#0D0D0D]" />
                  Create News Story
                </>
              )}
            </button>
          </form>
 
          {error && (
            <div className="mt-3 flex items-start gap-1.5 p-2 bg-terracotta-500/10 rounded-none border border-terracotta-500/25 text-neutral-300 text-[9px] font-mono leading-tight">
              <AlertCircle className="w-3.5 h-3.5 text-terracotta-500 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}
        </div>
 
        {/* Right Side: Editorial Article Output */}
        <div className="lg:col-span-7 flex flex-col justify-center min-h-[300px] border-t lg:border-t-0 lg:border-l border-white/10 pt-6 lg:pt-0 lg:pl-8">
          <AnimatePresence mode="wait">
            {loading ? (
              <motion.div
                key="loading-state"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center text-center py-12"
              >
                <div className="w-10 h-10 rounded-none border-t border-r border-terracotta-500 animate-spin mb-4" />
                <span className="text-xs font-mono uppercase tracking-widest text-neutral-400">Writing your customized story</span>
                <span className="text-[10px] font-serif text-neutral-500 italic mt-1">"Thinking of funny headlines for you..."</span>
              </motion.div>
            ) : article ? (
              <motion.div
                key="article-state"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="space-y-4"
              >
                {/* Meta details */}
                <div className="flex justify-between items-center text-[10px] font-mono text-neutral-500 uppercase tracking-widest border-b border-white/10 pb-1">
                  <span>{article.date}</span>
                  <span>{article.location}</span>
                </div>
 
                {/* Headline */}
                <h3 className="text-xl md:text-2xl font-serif font-bold text-white leading-tight uppercase tracking-tight">
                  {article.headline}
                </h3>
 
                {/* Subheading */}
                <p className="text-xs font-serif italic text-neutral-400 leading-relaxed border-l-2 border-terracotta-500 pl-3">
                  {article.subheading}
                </p>
 
                {/* Dynamic Insider score */}
                <div className="bg-white/5 p-2.5 rounded-none border border-white/10 flex items-center justify-between">
                  <span className="text-[9px] font-mono text-neutral-400 uppercase tracking-widest">Brick Fun Score:</span>
                  <span className="text-xs font-mono font-bold text-terracotta-500 uppercase tracking-wider">{article.insiderScore}</span>
                </div>
 
                {/* Body Content */}
                <div className="text-xs font-serif leading-relaxed text-neutral-300 space-y-3">
                  {article.content.map((p, idx) => (
                    <p key={idx} className={idx === 0 ? 'first-letter:text-3xl first-letter:font-bold first-letter:float-left first-letter:mr-2 first-letter:text-terracotta-500' : ''}>
                      {p}
                    </p>
                  ))}
                </div>
 
                {/* Pretentious Quote block */}
                {article.editorialQuote && (
                  <div className="bg-white/[0.02] p-4 rounded-none border-l-2 border-terracotta-500 flex gap-3 italic text-neutral-300">
                    <Quote className="w-5 h-5 text-terracotta-500 shrink-0 rotate-180" />
                    <p className="text-xs font-serif leading-relaxed">
                      "{article.editorialQuote}"
                    </p>
                  </div>
                )}
              </motion.div>
            ) : (
              <motion.div
                key="empty-state"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center text-center py-12 text-neutral-500"
              >
                <BookOpen className="w-10 h-10 stroke-[1.2] mb-3 text-terracotta-500" />
                <h4 className="text-sm font-serif font-bold text-neutral-300 uppercase tracking-wider font-light">Ready to Create Your Story</h4>
                <p className="text-[10px] font-mono max-w-xs mt-1 leading-normal">
                  Type your name and choose your style on the left to generate your customized story!
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
