import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Shield, Compass, Truck, Gift, Check, ShoppingBag, X } from 'lucide-react';
import { BrickFinish, CustomizationState } from '../types';
import Brick3D from './Brick3D';

interface CustomizeSectionProps {
  onSuccessBuy: (custom: CustomizationState, finalPrice: number) => void;
}

export default function CustomizeSection({ onSuccessBuy }: CustomizeSectionProps) {
  const [custom, setCustom] = useState<CustomizationState>({
    finish: 'classic',
    engraving: '',
    velvetStand: false,
    organicMossStarter: false,
    perfumed: 'none',
    packaging: 'standard',
  });

  const [checkoutOpen, setCheckoutOpen] = useState(false);

  // Price calculations
  const BASE_PRICES: Record<BrickFinish, number> = {
    classic: 14500,
    obsidian: 18900,
    sovereign: 29500,
    moss: 21200,
  };

  const getAddonPrices = () => {
    let addons = 0;
    if (custom.velvetStand) addons += 1500;
    if (custom.organicMossStarter) addons += 1200;
    if (custom.perfumed === 'eau_de_terre') addons += 1000;
    if (custom.perfumed === 'esprit_de_kiln') addons += 1400;
    if (custom.packaging === 'mahogany_chest') addons += 3500;
    if (custom.packaging === 'carbon_vault') addons += 5500;
    return addons;
  };

  const basePrice = BASE_PRICES[custom.finish];
  const addonPrice = getAddonPrices();
  const totalPrice = basePrice + addonPrice;

  const handleFinishChange = (finish: BrickFinish) => {
    setCustom((prev) => ({ ...prev, finish }));
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const text = e.target.value.toUpperCase();
    if (text.length <= 15) {
      setCustom((prev) => ({ ...prev, engraving: text }));
    }
  };

  const toggleStand = () => {
    setCustom((prev) => ({ ...prev, velvetStand: !prev.velvetStand }));
  };

  const toggleMoss = () => {
    setCustom((prev) => ({ ...prev, organicMossStarter: !prev.organicMossStarter }));
  };

  const handlePerfume = (perfumed: 'none' | 'eau_de_terre' | 'esprit_de_kiln') => {
    setCustom((prev) => ({ ...prev, perfumed }));
  };

  const handlePackaging = (packaging: 'standard' | 'mahogany_chest' | 'carbon_vault') => {
    setCustom((prev) => ({ ...prev, packaging }));
  };

  const handleSecureAllocation = () => {
    setCheckoutOpen(true);
  };

  const handleConfirmOrder = () => {
    setCheckoutOpen(false);
    onSuccessBuy(custom, totalPrice);
  };

  return (
    <div className="w-full bg-[#0D0D0D] border border-white/10 rounded-none p-6 md:p-10 text-white">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
        
        {/* Left column: 3D Render Canvas */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center bg-black/40 rounded-none p-6 border border-white/10 min-h-[350px] relative">
          <div className="absolute top-4 left-4 flex gap-1.5 items-center">
            <span className="w-2 h-2 rounded-full bg-terracotta-500 animate-ping" />
            <span className="text-[9px] font-mono tracking-[0.15em] text-neutral-400 uppercase">
              Interactive 3D Preview (Drag to rotate)
            </span>
          </div>
 
          <Brick3D finish={custom.finish} engraving={custom.engraving} className="scale-95 md:scale-100" />
 
          {/* Micro stats under brick */}
          <div className="mt-4 flex gap-6 text-[10px] font-mono text-neutral-500 uppercase tracking-widest border-t border-white/10 pt-4 w-full justify-center">
            <span>Mass: 4.3 lbs</span>
            <span>Refractive Index: 1.54</span>
            <span>Resonance: 120Hz</span>
          </div>
        </div>
 
        {/* Right column: Configurator Details */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
          <div>
            <span className="text-[10px] font-mono text-terracotta-500 uppercase tracking-[0.2em] block mb-1">
              Configure Your Brick
            </span>
            <h3 className="text-2xl md:text-3xl font-serif text-white tracking-wide font-light uppercase">
              BRICK MODEL NO. 1
            </h3>
            <p className="text-xs text-neutral-400 mt-1.5 leading-relaxed font-serif">
              Design your custom kiln-fired clay solid brick. Choose your color, write a custom name, and select a beautiful box.
            </p>
          </div>
 
          {/* Config options */}
          <div className="space-y-4">
            
            {/* 1. Finishes */}
            <div>
              <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-2">
                1. Choose Brick Color/Style
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
                {[
                  { value: 'classic', label: 'Classic Red', desc: 'Real Clay Color' },
                  { value: 'obsidian', label: 'Obsidian Black', desc: 'Elegant Dark Style' },
                  { value: 'sovereign', label: 'Sovereign Gold', desc: 'Shiny Gold Coating' },
                  { value: 'moss', label: 'Natural Moss', desc: 'Living Forest Look' },
                ].map((item) => (
                  <button
                    key={item.value}
                    onClick={() => handleFinishChange(item.value as BrickFinish)}
                    className={`p-2.5 rounded-none text-left border transition-all ${
                      custom.finish === item.value
                        ? 'border-terracotta-500 bg-terracotta-500/10 text-white'
                        : 'border-white/10 bg-black/20 text-neutral-400 hover:border-white/30'
                    }`}
                  >
                    <span className="block text-xs font-mono font-bold tracking-wide uppercase">
                      {item.label}
                    </span>
                    <span className="block text-[8px] opacity-70 mt-0.5 leading-none">
                      {item.desc}
                    </span>
                  </button>
                ))}
              </div>
            </div>
 
            {/* 2. Custom laser engraving */}
            <div>
              <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                2. Write a Custom Name on Your Brick (Up to 15 letters)
              </label>
              <input
                type="text"
                placeholder="e.g., MY BRICK"
                value={custom.engraving}
                onChange={handleTextChange}
                className="w-full bg-black/40 border border-white/10 rounded-none px-3 py-2 text-xs font-mono tracking-widest text-white uppercase placeholder-neutral-700 focus:outline-none focus:border-terracotta-500"
              />
            </div>
 
            {/* 3. Luxury Add-ons */}
            <div>
              <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-2">
                3. Add Extra Accessories
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                {/* Velvet Stand */}
                <button
                  onClick={toggleStand}
                  className={`flex items-center justify-between p-2.5 rounded-none border text-left transition-all ${
                    custom.velvetStand
                      ? 'border-terracotta-500 bg-terracotta-500/10 text-white'
                      : 'border-white/10 bg-black/20 text-neutral-400 hover:border-white/30'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Check className={`w-3.5 h-3.5 text-terracotta-500 transition-all ${custom.velvetStand ? 'opacity-100 scale-100' : 'opacity-20 scale-90'}`} />
                    <div>
                      <span className="block text-xs font-mono uppercase font-bold">Black Velvet Stand</span>
                      <span className="block text-[8px] opacity-70 leading-none mt-0.5">Soft display cushion stand</span>
                    </div>
                  </div>
                  <span className="text-xs font-mono text-terracotta-500 font-semibold">+$1,500</span>
                </button>
  
                {/* Organic Moss starter spores */}
                <button
                  onClick={toggleMoss}
                  className={`flex items-center justify-between p-2.5 rounded-none border text-left transition-all ${
                    custom.organicMossStarter
                      ? 'border-terracotta-500 bg-terracotta-500/10 text-white'
                      : 'border-white/10 bg-black/20 text-neutral-400 hover:border-white/30'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Check className={`w-3.5 h-3.5 text-terracotta-500 transition-all ${custom.organicMossStarter ? 'opacity-100 scale-100' : 'opacity-20 scale-90'}`} />
                    <div>
                      <span className="block text-xs font-mono uppercase font-bold">Moss Starter Spores</span>
                      <span className="block text-[8px] opacity-70 leading-none mt-0.5">Seeds to grow real moss on clay</span>
                    </div>
                  </div>
                  <span className="text-xs font-mono text-terracotta-500 font-semibold">+$1,200</span>
                </button>
              </div>
            </div>
 
            {/* 4. Perfumery and Chest packaging */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Perfume */}
              <div>
                <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                  4. Choose Scent Sensation
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { value: 'none', label: 'Unscented', price: 0 },
                    { value: 'eau_de_terre', label: 'Rain & Clay', price: 1000 },
                    { value: 'esprit_de_kiln', label: 'Warm Smoke', price: 1400 },
                  ].map((p) => (
                    <button
                      key={p.value}
                      onClick={() => handlePerfume(p.value as any)}
                      className={`py-2 px-1 text-center rounded-none border transition-all ${
                        custom.perfumed === p.value
                          ? 'border-terracotta-500 bg-terracotta-500/10 text-white'
                          : 'border-white/10 bg-black/30 text-neutral-500 hover:border-white/30 text-[10px]'
                      }`}
                    >
                      <span className="block text-[10px] font-mono font-bold uppercase">{p.label}</span>
                      <span className="block text-[8px] text-terracotta-500 font-mono mt-0.5">{p.price > 0 ? `+$${p.price}` : 'Free'}</span>
                    </button>
                  ))}
                </div>
              </div>
 
              {/* Box casing */}
              <div>
                <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                  5. Choose Box Casing
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { value: 'standard', label: 'Cardboard Box', price: 0 },
                    { value: 'mahogany_chest', label: 'Wooden Box', price: 3500 },
                    { value: 'carbon_vault', label: 'Carbon Case', price: 5500 },
                  ].map((c) => (
                    <button
                      key={c.value}
                      onClick={() => handlePackaging(c.value as any)}
                      className={`py-2 px-1 text-center rounded-none border transition-all ${
                        custom.packaging === c.value
                          ? 'border-terracotta-500 bg-terracotta-500/10 text-white'
                          : 'border-white/10 bg-black/30 text-neutral-500 hover:border-white/30 text-[10px]'
                      }`}
                    >
                      <span className="block text-[10px] font-mono font-bold uppercase">{c.label.split(' ')[0]}</span>
                      <span className="block text-[8px] text-terracotta-500 font-mono mt-0.5">{c.price > 0 ? `+$${c.price}` : 'Free'}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
 
          </div>
 
          {/* Pricing bar and Purchase Trigger */}
          <div className="pt-6 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest block">
                Total Order Price
              </span>
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-serif text-white font-bold tracking-wide">
                  ${totalPrice.toLocaleString()}
                </span>
                <span className="text-xs font-mono text-neutral-400">USD</span>
              </div>
            </div>
 
            <button
              onClick={handleSecureAllocation}
              className="w-full md:w-auto px-8 py-4 bg-[#E5E5E5] hover:bg-white text-[#0D0D0D] font-mono text-xs uppercase tracking-[0.3em] font-bold rounded-none transition-all flex items-center justify-center gap-2"
            >
              <ShoppingBag className="w-4 h-4 text-[#0D0D0D]" /> Buy Now
            </button>
          </div>
 
        </div>
      </div>
 
      {/* Checkout Allocation Modal */}
      <AnimatePresence>
        {checkoutOpen && (
          <div className="fixed inset-0 bg-black/95 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#E5E5E5] text-[#0D0D0D] max-w-md w-full rounded-none border-2 border-[#0D0D0D] shadow-2xl p-6 relative"
            >
              <button
                onClick={() => setCheckoutOpen(false)}
                className="absolute top-4 right-4 text-stone-600 hover:text-stone-900 transition-colors bg-[#0D0D0D]/5 p-1.5"
              >
                <X className="w-5 h-5" />
              </button>
 
              <div className="text-center">
                <div className="w-12 h-12 bg-terracotta-500/10 rounded-none flex items-center justify-center mx-auto border border-terracotta-500/25 mb-3 text-terracotta-500">
                  <Sparkles className="w-6 h-6" />
                </div>
                <h4 className="text-lg font-serif tracking-wide text-[#0D0D0D] uppercase font-light">Order Pre-Approved</h4>
                <p className="text-[11px] font-mono text-neutral-500 uppercase tracking-wider mt-1">
                  ORDER STATUS: <span className="text-terracotta-500 font-bold">READY</span>
                </p>
              </div>
 
              <div className="mt-5 space-y-3 bg-[#0D0D0D] text-white p-4 rounded-none border border-white/10">
                <div className="flex justify-between items-center text-xs font-mono text-neutral-400">
                  <span>Product Model:</span>
                  <span className="text-white uppercase">Le BRK Brick No. 1</span>
                </div>
                <div className="flex justify-between items-center text-xs font-mono text-neutral-400">
                  <span>Brick Finish:</span>
                  <span className="text-white uppercase font-bold">{custom.finish}</span>
                </div>
                <div className="flex justify-between items-center text-xs font-mono text-neutral-400">
                  <span>Custom Engraving:</span>
                  <span className="text-white italic">{custom.engraving || 'None (Plain Clay)'}</span>
                </div>
                <div className="flex justify-between items-center text-xs font-mono text-neutral-400">
                  <span>Choose Scent:</span>
                  <span className="text-white uppercase">{custom.perfumed.replace(/_/g, ' ')}</span>
                </div>
                <div className="flex justify-between items-center text-xs font-mono text-neutral-400">
                  <span>Casing Box:</span>
                  <span className="text-white uppercase">{custom.packaging.replace(/_/g, ' ')}</span>
                </div>
                <div className="border-t border-white/10 pt-3 flex justify-between items-baseline font-serif">
                  <span className="text-xs text-neutral-400 uppercase">Total Order Price:</span>
                  <span className="text-xl font-bold text-terracotta-500">${totalPrice.toLocaleString()}</span>
                </div>
              </div>
 
              <div className="mt-5 flex gap-2">
                <div className="bg-[#0D0D0D]/5 px-3 py-2.5 rounded-none border border-[#0D0D0D]/10 flex-1 flex items-center gap-2 text-left">
                  <Truck className="w-4 h-4 text-stone-600" />
                  <div>
                    <span className="block text-[8px] font-mono text-stone-500 uppercase">Fast Shipping</span>
                    <span className="block text-[10px] font-sans font-semibold text-stone-800">Arrives in 2-3 Days</span>
                  </div>
                </div>
                <div className="bg-[#0D0D0D]/5 px-3 py-2.5 rounded-none border border-[#0D0D0D]/10 flex-1 flex items-center gap-2 text-left">
                  <Shield className="w-4 h-4 text-stone-600" />
                  <div>
                    <span className="block text-[8px] font-mono text-stone-500 uppercase">Safe Delivery</span>
                    <span className="block text-[10px] font-sans font-semibold text-stone-800">100% Real Clay</span>
                  </div>
                </div>
              </div>
 
              <button
                onClick={handleConfirmOrder}
                className="mt-6 w-full py-4 bg-[#0D0D0D] hover:bg-neutral-800 text-white font-mono text-xs uppercase tracking-[0.3em] font-bold rounded-none transition-all"
              >
                Confirm & Buy Brick
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
