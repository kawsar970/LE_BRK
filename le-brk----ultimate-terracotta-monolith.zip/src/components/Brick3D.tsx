import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { BrickFinish } from '../types';

interface Brick3DProps {
  finish: BrickFinish;
  engraving: string;
  className?: string;
  interactive?: boolean;
}

export default function Brick3D({ finish, engraving, className = '', interactive = true }: Brick3DProps) {
  const [rotation, setRotation] = useState({ x: -15, y: 45 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });
  const rotationStart = useRef({ x: 0, y: 0 });
  const autoRotateRef = useRef<number | null>(null);

  // Auto-rotation when not dragging
  useEffect(() => {
    if (isDragging || !interactive) return;

    const tick = () => {
      setRotation((prev) => ({
        ...prev,
        y: (prev.y + 0.15) % 360,
      }));
      autoRotateRef.current = requestAnimationFrame(tick);
    };

    autoRotateRef.current = requestAnimationFrame(tick);
    return () => {
      if (autoRotateRef.current) cancelAnimationFrame(autoRotateRef.current);
    };
  }, [isDragging, interactive]);

  const handlePointerDown = (e: React.PointerEvent) => {
    if (!interactive) return;
    setIsDragging(true);
    dragStart.current = { x: e.clientX, y: e.clientY };
    rotationStart.current = { x: rotation.x, y: rotation.y };
    if (autoRotateRef.current) cancelAnimationFrame(autoRotateRef.current);
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging || !interactive) return;
    const dx = e.clientX - dragStart.current.x;
    const dy = e.clientY - dragStart.current.y;

    // Limit X rotation to avoid flipping upside down completely
    const newX = Math.max(-60, Math.min(60, rotationStart.current.x - dy * 0.5));
    const newY = rotationStart.current.y + dx * 0.5;

    setRotation({ x: newX, y: newY });
  };

  const handlePointerUp = () => {
    setIsDragging(false);
  };

  // Brick Dimensions
  const w = 220; // Width (X)
  const h = 75;  // Height (Y)
  const d = 110; // Depth (Z)

  // Style configurations for different finishes
  const getFaceStyle = (face: 'front' | 'back' | 'top' | 'bottom' | 'left' | 'right') => {
    switch (finish) {
      case 'obsidian':
        return {
          base: 'border border-neutral-800/40 bg-gradient-to-br from-[#1c1c1c] via-[#121212] to-[#0a0a0a]',
          text: 'text-luxury-gold/50 text-shadow-gold tracking-[0.2em] font-serif',
          shading: face === 'top' ? 'brightness-125' : face === 'left' || face === 'bottom' ? 'brightness-75' : 'brightness-100',
        };
      case 'sovereign':
        return {
          base: 'border border-yellow-600/30 bg-gradient-to-br from-amber-200 via-yellow-500 to-amber-700 shadow-[inset_0_0_20px_rgba(255,255,255,0.4)]',
          text: 'text-amber-950/70 font-semibold tracking-widest font-serif',
          shading: face === 'top' ? 'brightness-110' : face === 'left' || face === 'bottom' ? 'brightness-75' : 'brightness-90',
        };
      case 'moss':
        if (face === 'top') {
          return {
            base: 'border border-emerald-900 bg-gradient-to-br from-green-800 via-emerald-700 to-amber-950 shadow-[inset_0_0_30px_rgba(0,0,0,0.5)]',
            text: 'text-stone-300/60 font-medium tracking-wider font-serif',
            shading: 'brightness-100',
            overlay: 'Mossy Velvet Plaque'
          };
        }
        return {
          base: 'border border-orange-950 bg-gradient-to-br from-[#8a331a] via-[#6e220f] to-[#4f1306]',
          text: 'text-stone-900/40 font-semibold tracking-wider font-serif',
          shading: face === 'left' || face === 'bottom' ? 'brightness-75' : 'brightness-90',
        };
      case 'classic':
      default:
        return {
          base: 'border border-orange-950/40 bg-gradient-to-br from-orange-800 via-terracotta-500 to-terracotta-700 shadow-[inset_0_0_15px_rgba(0,0,0,0.2)]',
          text: 'text-orange-950/60 font-semibold tracking-widest font-serif',
          shading: face === 'top' ? 'brightness-110' : face === 'left' || face === 'bottom' ? 'brightness-75' : 'brightness-90',
        };
    }
  };

  // Face Transform Definitions
  const faces = [
    { name: 'front', width: w, height: h, transform: `translate(-50%, -50%) rotateY(0deg) translateZ(${d / 2}px)` },
    { name: 'back', width: w, height: h, transform: `translate(-50%, -50%) rotateY(180deg) translateZ(${d / 2}px)` },
    { name: 'top', width: w, height: d, transform: `translate(-50%, -50%) rotateX(90deg) translateZ(${h / 2}px)` },
    { name: 'bottom', width: w, height: d, transform: `translate(-50%, -50%) rotateX(-90deg) translateZ(${h / 2}px)` },
    { name: 'left', width: d, height: h, transform: `translate(-50%, -50%) rotateY(-90deg) translateZ(${w / 2}px)` },
    { name: 'right', width: d, height: h, transform: `translate(-50%, -50%) rotateY(90deg) translateZ(${w / 2}px)` },
  ] as const;

  return (
    <div
      className={`relative select-none ${className} flex items-center justify-center`}
      style={{ perspective: '800px', width: `${w + 80}px`, height: `${d + 120}px` }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      {/* Absolute floor shadow representing extreme high-quality rendering */}
      <div 
        className="absolute bottom-6 w-52 h-10 bg-black/60 rounded-full blur-xl mix-blend-multiply pointer-events-none transition-all duration-300"
        style={{
          transform: `scale(${1 - Math.abs(rotation.x) / 120})`,
          opacity: 0.85
        }}
      />

      {/* 3D Container */}
      <div
        className="relative w-full h-full transition-transform duration-75"
        style={{
          transformStyle: 'preserve-3d',
          transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)`,
          cursor: interactive ? (isDragging ? 'grabbing' : 'grab') : 'default',
        }}
      >
        {faces.map((f) => {
          const style = getFaceStyle(f.name);
          return (
            <div
              key={f.name}
              className={`absolute left-1/2 top-1/2 transition-colors duration-500 overflow-hidden select-none pointer-events-none ${style.base} ${style.shading}`}
              style={{
                width: `${f.width}px`,
                height: `${f.height}px`,
                transform: f.transform,
                transformStyle: 'preserve-3d',
                backfaceVisibility: 'visible',
              }}
            >
              {/* Add physical porous grain details to represent pure luxury clay block */}
              <div className="absolute inset-0 bg-[radial-gradient(#000000_1px,transparent_1px)] [background-size:16px_16px] opacity-15 mix-blend-overlay pointer-events-none" />
              <div className="absolute inset-0 bg-noise opacity-[0.03] mix-blend-overlay" />

              {/* Special Moss decoration on Top face */}
              {finish === 'moss' && f.name === 'top' && (
                <div className="absolute inset-x-2 top-2 bottom-2 bg-gradient-to-br from-emerald-600 via-green-700 to-amber-900 rounded-sm filter blur-[2px] opacity-90 border border-emerald-500/20">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-[9px] font-sans text-emerald-100/50 uppercase tracking-widest text-center font-light leading-none">
                      Organic Accretion
                    </span>
                  </div>
                </div>
              )}

              {/* Custom Laser Engraving - Only on Front face */}
              {f.name === 'front' && (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-3 text-center">
                  <div className="text-[8px] tracking-[0.3em] opacity-40 font-mono uppercase mb-1">
                    LE BRK
                  </div>
                  {engraving ? (
                    <motion.div
                      key={engraving}
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className={`text-xs md:text-sm font-serif ${style.text} max-w-[180px] break-words uppercase font-light tracking-[0.15em] border-t border-b py-1 border-current/20`}
                    >
                      {engraving}
                    </motion.div>
                  ) : (
                    <div className="text-[10px] tracking-[0.2em] opacity-35 font-serif uppercase italic font-light">
                      SERIES NO. 01
                    </div>
                  )}
                  <div className="absolute bottom-2 text-[7px] font-mono opacity-25 tracking-[0.1em]">
                    KILN-FIRED 2026
                  </div>
                </div>
              )}

              {/* Aesthetic golden accent line on Obsidian skin */}
              {finish === 'obsidian' && (
                <div className="absolute inset-0 border border-luxury-gold/10 pointer-events-none" />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
