import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, RotateCcw, Trophy, ShieldAlert, Award, Star, ArrowUp } from 'lucide-react';
import { LeaderboardEntry } from '../types';

// Predefined Elite Leaderboard entries for satirical realism
const DEFAULT_LEADERBOARD: LeaderboardEntry[] = [
  { name: 'Baroness von Clay', score: 28, archetype: 'Silent Wealth Oligarch', title: 'Sovereign Architectural Deity' },
  { name: 'Arch. Kengo Stone', score: 22, archetype: 'Minimalist Architect', title: 'Sovereign Architectural Deity' },
  { name: 'Sir Heavy-Load', score: 17, archetype: 'Brutalist Pioneer', title: 'Brutalist Oligarch' },
  { name: 'Nouveau-Riche Nick', score: 8, archetype: 'Crypto Philanthropist', title: 'Neoclassical Mason' },
];

export default function StackGame() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [rankTitle, setRankTitle] = useState('Suburban Foundation Layperson');
  const [playerName, setPlayerName] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Game engine variables (using refs to avoid re-running useEffect)
  const stateRef = useRef({
    score: 0,
    cameraY: 0,
    targetCameraY: 0,
    speedMultiplier: 1,
    blocks: [] as Array<{
      x: number;
      y: number;
      w: number;
      color: string;
      speed: number;
      direction: number; // -1 or 1
      isPlaced: boolean;
    }>,
    particles: [] as Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      color: string;
      alpha: number;
    }>,
    texts: [] as Array<{
      x: number;
      y: number;
      text: string;
      color: string;
      alpha: number;
    }>,
    isPlacedThisTurn: false,
  });

  // Get rank title based on score
  const getRankTitle = (s: number) => {
    if (s >= 25) return 'Master Builder';
    if (s >= 18) return 'Senior Builder';
    if (s >= 12) return 'Professional Mason';
    if (s >= 7) return 'Good Bricklayer';
    if (s >= 3) return 'Apprentice';
    return 'Beginner Builder';
  };

  // Load High Score and Leaderboard on Mount
  useEffect(() => {
    const savedHighScore = localStorage.getItem('brk_high_score');
    if (savedHighScore) {
      setHighScore(parseInt(savedHighScore, 10));
    }
    const savedLeaderboard = localStorage.getItem('brk_leaderboard');
    if (savedLeaderboard) {
      setLeaderboard(JSON.parse(savedLeaderboard));
    } else {
      setLeaderboard(DEFAULT_LEADERBOARD);
      localStorage.setItem('brk_leaderboard', JSON.stringify(DEFAULT_LEADERBOARD));
    }
  }, []);

  // Set Canvas Dimension & Resize Handling
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resize = () => {
      const container = containerRef.current;
      if (!container) return;
      canvas.width = container.clientWidth;
      canvas.height = 450;
    };

    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, []);

  // Main Game Loop
  useEffect(() => {
    if (!isPlaying || isGameOver) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      // Clear with elegant charcoal slate gradient
      ctx.fillStyle = '#141414';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw subtle grid lines representing premium planning paper
      ctx.strokeStyle = 'rgba(178, 34, 34, 0.06)';
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }
 
      const state = stateRef.current;
 
      // Smooth Camera tracking
      state.cameraY += (state.targetCameraY - state.cameraY) * 0.1;
 
      // Game boundary check
      const baselineY = canvas.height - 50 + state.cameraY;
 
      // Draw baseline foundation
      ctx.fillStyle = '#1A1A1A';
      ctx.fillRect(0, baselineY, canvas.width, 20);
      ctx.fillStyle = '#B22222'; // Terracotta crimson line
      ctx.fillRect(0, baselineY - 2, canvas.width, 2);
 
      // Draw placed and moving blocks
      state.blocks.forEach((block, index) => {
        const renderY = block.y + state.cameraY;
 
        // Skip rendering if block is way off screen
        if (renderY > canvas.height + 100 || renderY < -100) return;
 
        // Colors
        let blockColor = block.color;
        let borderGold = index === state.blocks.length - 1 && !block.isPlaced;
 
        // Shadow representing physical weight
        ctx.shadowColor = 'rgba(0, 0, 0, 0.35)';
        ctx.shadowBlur = 8;
        ctx.shadowOffsetY = 4;
 
        // Draw block body
        ctx.fillStyle = blockColor;
        ctx.fillRect(block.x, renderY, block.w, 24);
 
        ctx.shadowBlur = 0; // reset shadow
        ctx.shadowOffsetY = 0;
 
        // Clean high-contrast trim
        ctx.strokeStyle = borderGold ? '#B22222' : 'rgba(0, 0, 0, 0.35)';
        ctx.lineWidth = borderGold ? 2 : 1;
        ctx.strokeRect(block.x, renderY, block.w, 24);
 
        // Brick porous texture
        ctx.fillStyle = 'rgba(0,0,0,0.1)';
        for (let ox = 5; ox < block.w; ox += 25) {
          ctx.fillRect(block.x + ox, renderY + 5, 2, 2);
          ctx.fillRect(block.x + ox + 10, renderY + 15, 2, 2);
        }
 
        // Active target line guide to help precision stacking (high fashion HUD)
        if (!block.isPlaced) {
          ctx.strokeStyle = 'rgba(178, 34, 34, 0.15)';
          ctx.setLineDash([4, 4]);
          ctx.beginPath();
          ctx.moveTo(block.x + block.w / 2, 0);
          ctx.lineTo(block.x + block.w / 2, canvas.height);
          ctx.stroke();
          ctx.setLineDash([]);
        }
      });

      // Update active block movement
      const activeBlockIndex = state.blocks.length - 1;
      if (activeBlockIndex >= 0) {
        const activeBlock = state.blocks[activeBlockIndex];
        if (!activeBlock.isPlaced) {
          activeBlock.x += activeBlock.speed * activeBlock.direction * state.speedMultiplier;

          // Boundary bounce
          if (activeBlock.x <= 0) {
            activeBlock.x = 0;
            activeBlock.direction = 1;
          } else if (activeBlock.x + activeBlock.w >= canvas.width) {
            activeBlock.x = canvas.width - activeBlock.w;
            activeBlock.direction = -1;
          }
        }
      }

      // Update and Draw Particles
      state.particles = state.particles.filter((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.2; // Gravity
        p.alpha -= 0.02;
        if (p.alpha <= 0) return false;

        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.fillRect(p.x, p.y + state.cameraY, p.size, p.size);
        ctx.globalAlpha = 1;
        return true;
      });

      // Update and Draw Society Reviews / Praise Texts
      state.texts = state.texts.filter((t) => {
        t.y -= 0.8;
        t.alpha -= 0.015;
        if (t.alpha <= 0) return false;

        ctx.fillStyle = t.color;
        ctx.globalAlpha = t.alpha;
        ctx.font = 'italic 500 12px "Cormorant Garamond", Georgia, serif';
        ctx.fillText(t.text, t.x, t.y + state.cameraY);
        ctx.globalAlpha = 1;
        return true;
      });

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, isGameOver]);

  // Drop Brick Handler
  const dropBlock = () => {
    if (!isPlaying || isGameOver) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const state = stateRef.current;
    const activeIndex = state.blocks.length - 1;
    if (activeIndex < 0) return;

    const activeBlock = state.blocks[activeIndex];
    if (activeBlock.isPlaced) return;

    // Previous placed block
    const prevBlock = state.blocks[activeIndex - 1];

    let overlapLeft = activeBlock.x;
    let overlapRight = activeBlock.x + activeBlock.w;
    let success = false;

    // Word collection for praise floating up
    const accolades = ["PURE PERFECTION", "AUDACIOUS ACCURACY", "IMPECCABLE BALANCE", "ARISTOCRATIC CLINK", "ARCHITECTURAL HEGEMONY"];

    if (!prevBlock) {
      // First block dropped has no baseline, always success
      success = true;
      activeBlock.isPlaced = true;
    } else {
      const minX = Math.max(activeBlock.x, prevBlock.x);
      const maxX = Math.min(activeBlock.x + activeBlock.w, prevBlock.x + prevBlock.w);

      if (maxX > minX) {
        // Successful landing with overlap
        success = true;
        const choppedWidth = activeBlock.w - (maxX - minX);

        // Visual debris effects for chopped part
        const particleColor = activeBlock.color;
        const choppedX = activeBlock.x < prevBlock.x ? activeBlock.x : maxX;

        for (let i = 0; i < 20; i++) {
          state.particles.push({
            x: choppedX + Math.random() * Math.max(10, choppedWidth),
            y: activeBlock.y,
            vx: (Math.random() - 0.5) * 6 + (activeBlock.x < prevBlock.x ? -3 : 3),
            vy: (Math.random() - 0.5) * 4 - 2,
            size: 2 + Math.random() * 4,
            color: Math.random() > 0.4 ? particleColor : '#d4af37', // terracotta or gold specs
            alpha: 1,
          });
        }

        // Accolade text float
        const praise = accolades[Math.floor(Math.random() * accolades.length)];
        state.texts.push({
          x: minX + (maxX - minX) / 2 - 40,
          y: activeBlock.y - 15,
          text: praise,
          color: '#d4af37',
          alpha: 1,
        });

        // Slice brick to overlap size
        activeBlock.x = minX;
        activeBlock.w = maxX - minX;
        activeBlock.isPlaced = true;
      } else {
        // Absolute fail
        success = false;
      }
    }

    if (success) {
      const nextScore = score + 1;
      setScore(nextScore);
      setRankTitle(getRankTitle(nextScore));
      stateRef.current.score = nextScore;

      // Adjust camera target
      if (nextScore > 4) {
        state.targetCameraY = (nextScore - 4) * 24;
      }

      // Increase speed slightly for challenging pacing
      state.speedMultiplier = 1 + nextScore * 0.08;

      // Spawn next block
      const colors = ['#e25c38', '#cf4320', '#b93a19', '#9a2f14'];
      const finishColor = colors[nextScore % colors.length];

      const blockHeight = canvas.height - 50 - (nextScore + 1) * 24;

      // Place moving block
      state.blocks.push({
        x: Math.random() * (canvas.width - activeBlock.w),
        y: blockHeight,
        w: activeBlock.w,
        color: finishColor,
        speed: 3 + Math.random() * 2,
        direction: Math.random() > 0.5 ? 1 : -1,
        isPlaced: false,
      });
    } else {
      // Brick plunges down game over!
      setIsGameOver(true);
      if (score > highScore) {
        setHighScore(score);
        localStorage.setItem('brk_high_score', score.toString());
      }

      // Splat particles plunge
      for (let i = 0; i < 30; i++) {
        state.particles.push({
          x: activeBlock.x + activeBlock.w / 2 + (Math.random() - 0.5) * activeBlock.w,
          y: activeBlock.y,
          vx: (Math.random() - 0.5) * 10,
          vy: Math.random() * 8 + 4,
          size: 3 + Math.random() * 5,
          color: '#e25c38',
          alpha: 1,
        });
      }
    }
  };

  const startGame = () => {
    setIsPlaying(true);
    setIsGameOver(false);
    setScore(0);
    setSubmitted(false);
    setRankTitle('Beginner Builder');

    const canvas = canvasRef.current;
    if (!canvas) return;

    // Reset game engine state
    stateRef.current = {
      score: 0,
      cameraY: 0,
      targetCameraY: 0,
      speedMultiplier: 1,
      blocks: [
        {
          x: canvas.width / 2 - 90,
          y: canvas.height - 50 - 24,
          w: 180,
          color: '#e25c38', // classic clay
          speed: 0,
          direction: 0,
          isPlaced: true, // anchor block is placed
        },
        {
          x: 20,
          y: canvas.height - 50 - 48,
          w: 180,
          color: '#cf4320',
          speed: 4,
          direction: 1,
          isPlaced: false,
        },
      ],
      particles: [],
      texts: [],
      isPlacedThisTurn: false,
    };
  };

  const handleLeaderboardSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerName.trim()) return;

    const newEntry: LeaderboardEntry = {
      name: playerName,
      score: score,
      archetype: 'Bricklayer',
      title: rankTitle,
    };

    const updated = [...leaderboard, newEntry]
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);

    setLeaderboard(updated);
    localStorage.setItem('brk_leaderboard', JSON.stringify(updated));
    setSubmitted(true);
    setPlayerName('');
  };

  return (
    <div className="w-full bg-[#0D0D0D] rounded-none border border-white/10 shadow-none overflow-hidden max-w-2xl mx-auto flex flex-col text-white">
      {/* Header bar */}
      <div className="px-6 py-4 bg-black/40 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-none bg-terracotta-500 animate-pulse" />
          <span className="text-[10px] font-mono tracking-[0.15em] text-neutral-400 uppercase">BRICK STACKING MINI-GAME</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <span className="block text-[8px] font-mono text-neutral-500 uppercase tracking-wider">High Score</span>
            <span className="text-xs font-mono font-bold text-terracotta-500 tracking-wider">{highScore} Bricks</span>
          </div>
        </div>
      </div>
 
      <div className="flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-white/10 h-[450px] relative">
        {/* Main Canvas Viewport */}
        <div ref={containerRef} className="flex-1 relative bg-[#060606] flex items-center justify-center overflow-hidden">
          <canvas ref={canvasRef} className="absolute inset-0 block cursor-crosshair" onClick={dropBlock} />
 
          {/* Interactive HUD overlaid when playing */}
          {isPlaying && !isGameOver && (
            <div className="absolute top-4 left-4 right-4 flex justify-between items-start pointer-events-none">
              <div className="bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-none border border-white/10">
                <span className="block text-[8px] font-mono text-neutral-400 uppercase tracking-widest">Score</span>
                <span className="text-sm font-mono font-bold text-white tracking-wide">{score} <span className="text-[10px] text-neutral-500">Bricks</span></span>
              </div>
              <div className="bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-none border border-white/10 text-right">
                <span className="block text-[8px] font-mono text-neutral-400 uppercase tracking-widest">Your Rank</span>
                <span className="text-[10px] font-mono font-bold text-terracotta-500 uppercase tracking-wider">{rankTitle.split(' ')[0]}</span>
              </div>
            </div>
          )}
 
          {/* Start Screen Overlay */}
          {!isPlaying && (
            <div className="absolute inset-0 bg-black/90 backdrop-blur-sm flex flex-col items-center justify-center text-center p-6 z-10">
              <div className="w-12 h-12 bg-terracotta-500/10 rounded-none flex items-center justify-center mb-4 border border-terracotta-500/30">
                <ArrowUp className="w-6 h-6 text-terracotta-500 animate-bounce" />
              </div>
              <h3 className="text-xl font-serif text-white tracking-wider font-light uppercase">BRICK STACKER</h3>
              <p className="text-[11px] font-mono text-neutral-400 max-w-sm mt-2 leading-relaxed uppercase tracking-wider">
                Stack bricks carefully on top of each other! Try to build the highest tower. Any hanging parts of the brick will be cut off.
              </p>
              <button
                onClick={startGame}
                className="mt-6 flex items-center gap-2 px-6 py-3.5 bg-white text-[#0D0D0D] font-mono text-[10px] uppercase tracking-[0.25em] font-bold rounded-none transition-all active:scale-95 cursor-pointer"
              >
                <Play className="w-3 h-3 fill-current" /> Start Game
              </button>
            </div>
          )}
 
          {/* Game Over Screen Overlay */}
          {isGameOver && (
            <div className="absolute inset-0 bg-black/95 backdrop-blur-md flex flex-col items-center justify-center text-center p-6 z-10">
              <div className="w-12 h-12 bg-terracotta-500/10 rounded-none flex items-center justify-center border border-terracotta-500/30 mb-3 text-terracotta-500">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-serif text-terracotta-500 tracking-wider font-light uppercase">GAME OVER</h3>
              <p className="text-[11px] font-mono text-neutral-400 max-w-sm mt-1 leading-relaxed uppercase tracking-wider">
                The tower has collapsed! Your final score is <span className="text-white font-bold">{score} stacked bricks</span>.
              </p>
 
              <div className="mt-4 bg-white/5 p-3 rounded-none border border-white/10 max-w-xs w-full text-center">
                <span className="block text-[8px] font-mono text-neutral-500 uppercase tracking-widest">Your Title</span>
                <span className="text-xs font-mono text-terracotta-500 font-semibold uppercase">{rankTitle}</span>
              </div>
 
              {!submitted ? (
                <form onSubmit={handleLeaderboardSubmit} className="mt-4 max-w-xs w-full flex flex-col gap-2">
                  <span className="text-[9px] font-mono text-neutral-400 uppercase tracking-widest text-left">Save your score in the Leaderboard:</span>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Your Name"
                      value={playerName}
                      onChange={(e) => setPlayerName(e.target.value)}
                      maxLength={16}
                      className="flex-1 bg-black/60 border border-white/10 rounded-none px-3 py-1.5 text-xs text-white font-mono placeholder-neutral-700 focus:outline-none focus:border-terracotta-500"
                    />
                    <button
                      type="submit"
                      disabled={!playerName.trim()}
                      className="bg-white hover:bg-neutral-200 text-[#0D0D0D] px-4 py-1.5 rounded-none text-[10px] font-mono uppercase tracking-widest font-semibold transition-all disabled:opacity-50 cursor-pointer"
                    >
                      Save
                    </button>
                  </div>
                </form>
              ) : (
                <div className="mt-4 flex items-center gap-1.5 text-terracotta-500 text-xs font-mono bg-terracotta-500/10 px-3 py-1.5 rounded-none border border-terracotta-500/20">
                  <Award className="w-4 h-4" /> Saved on Leaderboard
                </div>
              )}
 
              <div className="flex gap-3 mt-6">
                <button
                  onClick={startGame}
                  className="flex items-center gap-2 px-6 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-mono text-[10px] uppercase tracking-widest rounded-none transition-all active:scale-95 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Retry
                </button>
              </div>
            </div>
          )}
        </div>
 
        {/* Side Panel: Registry & Leaders */}
        <div className="w-full md:w-56 bg-black/20 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-[0.15em] text-terracotta-500 border-b border-white/10 pb-2.5 mb-3">
              <Trophy className="w-3.5 h-3.5 text-terracotta-500" /> Leaderboard (Top Scores)
            </div>
            <div className="space-y-3">
              {leaderboard.map((entry, i) => (
                <div key={i} className="flex flex-col border-b border-white/5 pb-2">
                  <div className="flex justify-between items-center text-xs font-serif">
                    <span className="text-white font-light flex items-center gap-1">
                      <span className="text-[10px] font-mono text-neutral-500">{i + 1}.</span> {entry.name}
                    </span>
                    <span className="font-mono text-terracotta-500 font-bold">{entry.score} <span className="text-[9px] font-normal text-neutral-500">Bricks</span></span>
                  </div>
                  <span className="text-[8px] font-mono text-neutral-400 tracking-wider uppercase mt-1">{entry.title.split(' ')[0]}</span>
                </div>
              ))}
            </div>
          </div>
 
          <div className="mt-4 md:mt-0 pt-3 border-t border-white/10 text-center">
            <span className="text-[9px] font-mono text-neutral-500 uppercase leading-normal block tracking-wide">
              Place bricks precisely. Click or tap to drop. Overhang is lost.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
