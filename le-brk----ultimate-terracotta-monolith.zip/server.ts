import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Gemini AI news generation
  app.post("/api/generate-news", async (req, res) => {
    try {
      const { name, archetype, premiumAddon } = req.body;
      if (!name || !archetype) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        // Fallback mock generation if API key is missing
        const fallbackNews = generateFallbackNews(name, archetype, premiumAddon);
        return res.json({ news: fallbackNews });
      }

      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const systemPrompt = `You are an elite, high-society editor-in-chief for "The Monolith Journal", a fictional, extremely pretentious luxury lifestyle magazine catering to the 0.001% ultra-wealthy.
Your goal is to write a personalized, incredibly humorous, yet hyper-luxurious article about how the user (whose name, lifestyle archetype, and premium brick add-on are provided) has taken high society by storm by acquiring "Le BRK" (The ultimate premium terracotta brick).
Make it read like a piece from the Financial Times 'How to Spend It', Vogue, or Architectural Digest, but completely satirical and absurd because it is about a plain red clay brick.

Use these inputs:
- User Name: ${name}
- Archetype: ${archetype}
- Premium Customization: ${premiumAddon || "None"}

Generate JSON matching this exact typescript structure:
{
  "headline": "Short, striking, ultra-wealthy headline",
  "subheading": "A long, luxurious subtitle full of designer name-drops and status jargon",
  "date": "The elite society date",
  "location": "A high-society enclave (e.g., St. Moritz, Monaco, Kyoto Courtyards)",
  "content": [
    "Paragraph 1 discussing how ${name} (representing the ${archetype} community) shocked the elite by placing Le BRK in their pristine environment. Mention their customized option: '${premiumAddon}'.",
    "Paragraph 2 with a fake quote from a renowned designer or socialite praising ${name}'s sheer minimalist courage and architectural audacity.",
    "Paragraph 3 outlining how standard tech like smartphones are now being discarded in Monaco's harbors because 'clay is the only true un-hackable storage medium'."
  ],
  "editorialQuote": "An ultra-pretentious snippet of wisdom (e.g., 'In a world of pixels, the heavy red block is the ultimate security.')",
  "insiderScore": "A rating like '99.8% Sovereign Status' or 'Aristocratic Hegemony Achieved'"
}

Ensure the output is strictly valid JSON only. Do not wrap in markdown blocks, just return raw JSON. Do not include any text before or after the JSON.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: "Generate my personalized luxury news piece.",
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: "application/json",
          temperature: 0.8,
        }
      });

      const responseText = response.text || "";
      let newsData;
      try {
        newsData = JSON.parse(responseText.trim());
      } catch (parseError) {
        console.error("Failed to parse Gemini response as JSON, falling back. Raw response was:", responseText);
        newsData = generateFallbackNews(name, archetype, premiumAddon);
      }

      res.json(newsData);
    } catch (error: any) {
      console.error("Gemini news generation error:", error);
      const fallbackNews = generateFallbackNews(req.body.name, req.body.archetype, req.body.premiumAddon);
      res.json(fallbackNews);
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

function generateFallbackNews(name: string, archetype: string, premiumAddon: string) {
  const customStr = premiumAddon ? `infused with ${premiumAddon}` : "in its raw purist state";
  return {
    headline: `${name.toUpperCase()} SHOCKS ST. MORITZ WITH UNPRECEDENTED AUDACITY`,
    subheading: `The prominent ${archetype} redefines architectural minimalism with a single, perfectly balanced terracotta monolith.`,
    date: "SOCIETY SEASON 2026",
    location: "Monaco Riviera",
    content: [
      `In the sun-drenched courtyards of Monaco, a quiet revolution has taken place. ${name}, the visionary ${archetype}, has officially retired all digital devices in favor of Le BRK, customized exquisitely with ${customStr}. Socialites look on in stunned silence as the 4.3-pound terracotta block sits prominently on a Carrara marble pedestal, outclassing adjacent multi-million dollar sculptures.`,
      `\"It has zero pixels, infinite battery life, and cannot be hacked by Russian syndicates,\" remarked Baroness von Clay, her diamonds catching the sunlight. \"To place such an unapologetically heavy, silent object on one's mahogany desk is the ultimate expression of silent power. ${name} has single-handedly made screens look absolutely middle-class.\"`,
      `With an MSRP of $14,500, Le BRK has created a waitlist spanning three generations of Swiss bankers. It is rumored that luxury mega-yachts are currently replacing their anchor systems with solid gold-plated bricks, though purists insist that the raw, kiln-fired red clay remains the only true mark of high-society status.`
    ],
    editorialQuote: "In an age of digital noise, the heaviest, most silent object in the room wins.",
    insiderScore: "99.9% Aristocratic Hegemony"
  };
}

startServer();
